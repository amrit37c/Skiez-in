<?php

namespace App;

use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Http;
use SoapClient;
use Symfony\Component\Process\ExecutableFinder;
use App\WsseAuthHeader;
use SimpleXMLElement;

class ApisRequest extends Model
{
    //

    public function callApi($method, $url, $data)
    {
        try {
            $request = '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
                <soap:Header>
                <wsse:Security xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" soap:mustUnderstand="1">
                <wsse:UsernameToken xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd" wsu:Id="UsernameToken-17855236">
                <wsse:Username>APISKIEZTRAVEL</wsse:Username>
                <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">STL@5973</wsse:Password>
                </wsse:UsernameToken>
                </wsse:Security>
                </soap:Header>
                <soap:Body xmlns:ns2="http://www.opentravel.org/OTA/2003/05">
                <ns2:OTA_AirAvailRQ EchoToken="11868765275150-1300257933" PrimaryLangID="en-us" SequenceNmbr="1" Target="TEST" TimeStamp="2008-09-25T04:55:27" Version="20061.00">
                <ns2:POS>
                <ns2:Source TerminalID="TestUser/Test Runner">
                <ns2:RequestorID ID="APISKIEZTRAVEL" Type="4"/>
                <ns2:BookingChannel Type="12"/>
                </ns2:Source>
                </ns2:POS>
                <ns2:OriginDestinationInformation>
                <ns2:DepartureDateTime>2021-04-10T00:00:00</ns2:DepartureDateTime>
                <ns2:OriginLocation LocationCode="DEL"/>
                <ns2:DestinationLocation LocationCode="IKA"/>
                </ns2:OriginDestinationInformation>
                <ns2:TravelerInfoSummary>
                <ns2:AirTravelerAvail>
                <ns2:PassengerTypeQuantity Code="ADT" Quantity="1"/>
                </ns2:AirTravelerAvail>
                </ns2:TravelerInfoSummary>
                </ns2:OTA_AirAvailRQ>
                </soap:Body>
            </soap:Envelope>';
            function CallAPI($method, $url, $data = false)
            {
                $curl = curl_init();

                switch ($method) {
                    case "POST":
                        curl_setopt($curl, CURLOPT_POST, 1);

                        if ($data)
                            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                        break;
                    case "PUT":
                        curl_setopt($curl, CURLOPT_PUT, 1);
                        break;
                    default:
                        if ($data)
                            $url = sprintf("%s?%s", $url, http_build_query($data));
                }

                $headers = array("Content-type" => "text/xml");
                curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

                // Optional Authentication:
                curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
                curl_setopt($curl, CURLOPT_USERPWD, "username:password");

                curl_setopt($curl, CURLOPT_URL, $url);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

                $result = curl_exec($curl);

                curl_close($curl);
                return $result;
            }
            $result = CallAPI("POST", 'http://w5uat.isaaviations.com/webservices/services/AAResWebServices', $data);
            return $this->XMLtoJSON($result);
            return ($this->XMLtoJSON('<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
            <soap:Body xmlns:ns1="http://www.opentravel.org/OTA/2003/05">
            <ns1:OTA_AirAvailRS EchoToken="11868765275150-1300257933" PrimaryLangID="en-us" SequenceNmbr="1" TransactionIdentifier="TID$127106902861951458177791" Version="2006.01">
            <ns1:Success/>
            <ns1:Warnings/>
            <ns1:OriginDestinationInformation>
            <ns1:DepartureDateTime>2010-10-15T13:10:00</ns1:DepartureDateTime>
            <ns1:ArrivalDateTime>2010-10-15T19:10:00</ns1:ArrivalDateTime>
            <ns1:OriginLocation LocationCode="SHJ">Sharjah</ns1:OriginLocation>
            <ns1:DestinationLocation LocationCode="CMB">Colombo</ns1:DestinationLocation>
            <ns1:OriginDestinationOptions>
            <ns1:OriginDestinationOption>
            <ns1:FlightSegment ArrivalDateTime="2010-10-15T19:10:00" DepartureDateTime="2010-10-15T13:10:00" FlightNumber="G9507" RPH="221698">
            <ns1:DepartureAirport LocationCode="SHJ" Terminal="TerminalX"/>
            <ns1:ArrivalAirport LocationCode="CMB" Terminal="TerminalX"/>
            </ns1:FlightSegment>
            </ns1:OriginDestinationOption>
            </ns1:OriginDestinationOptions>
            </ns1:OriginDestinationInformation>
            <ns1:OriginDestinationInformation>
            <ns1:DepartureDateTime>2010-10-15T21:55:00</ns1:DepartureDateTime>
            <ns1:ArrivalDateTime>2010-10-16T03:35:00</ns1:ArrivalDateTime>
            <ns1:OriginLocation LocationCode="SHJ">Sharjah</ns1:OriginLocation>
            <ns1:DestinationLocation LocationCode="CMB">Colombo</ns1:DestinationLocation>
            <ns1:OriginDestinationOptions>
            <ns1:OriginDestinationOption>
            <ns1:FlightSegment ArrivalDateTime="2010-10-16T03:35:00" DepartureDateTime="2010-10-15T21:55:00" FlightNumber="G9505" RPH="206036">
            <ns1:DepartureAirport LocationCode="SHJ" Terminal="TerminalX"/>
            <ns1:ArrivalAirport LocationCode="CMB" Terminal="TerminalX"/>
            </ns1:FlightSegment>
            </ns1:OriginDestinationOption>
            </ns1:OriginDestinationOptions>
            </ns1:OriginDestinationInformation>
            <ns1:AAAirAvailRSExt>
            <ns1:PricedItineraries>
            <ns1:PricedItinerary SequenceNumber="1">
            <ns1:AirItinerary>
            <ns1:OriginDestinationOptions>
            <ns1:OriginDestinationOption>
            <ns1:FlightSegment ArrivalDateTime="2010-10-15T19:10:00" DepartureDateTime="2010-10-15T13:10:00" FlightNumber="G9507" RPH="221698-SHJCMBVSAOU">
            <ns1:DepartureAirport LocationCode="SHJ" Terminal="TerminalX"/>
            <ns1:ArrivalAirport LocationCode="CMB" Terminal="TerminalX"/>
            </ns1:FlightSegment>
            </ns1:OriginDestinationOption>
            </ns1:OriginDestinationOptions>
            </ns1:AirItinerary>
            <ns1:AirItineraryPricingInfo PricingSource="Published">
            <ns1:ItinTotalFare>
            <ns1:BaseFare Amount="470.00" CurrencyCode="AED" DecimalPlaces="2"/>
            <ns1:TotalFare Amount="971.00" CurrencyCode="AED" DecimalPlaces="2"/>
            <ns1:TotalEquivFare Amount="971.00" CurrencyCode="AED" DecimalPlaces="2"/>
            <ns1:TotalFareWithCCFee Amount="1000.13" CurrencyCode="AED" DecimalPlaces="2"/>
            <ns1:TotalEquivFareWithCCFee Amount="1000.13" CurrencyCode="AED" DecimalPlaces="2"/>
            </ns1:ItinTotalFare>
            <ns1:PTC_FareBreakdowns>
            <ns1:PTC_FareBreakdown PricingSource="Published">
            <ns1:PassengerTypeQuantity Code="ADT" Quantity="1"/>
            <ns1:FareBasisCodes>
            <ns1:FareBasisCode>P</ns1:FareBasisCode>
            </ns1:FareBasisCodes>
            <ns1:PassengerFare>
            <ns1:BaseFare Amount="470.00" CurrencyCode="AED" DecimalPlaces="2"/>
            <ns1:Taxes>
            <ns1:Tax Amount="75.00" CurrencyCode="AED" DecimalPlaces="2" TaxCode="ST" TaxName="SHARJAH APT TAX"/>
            <ns1:Tax Amount="221.00" CurrencyCode="AED" DecimalPlaces="2" TaxCode="CS" TaxName="Sri Lanka Travel Tax"/>
            </ns1:Taxes>
            <ns1:Fees>
            <ns1:Fee Amount="40.00" CurrencyCode="AED" DecimalPlaces="2" FeeCode="YO/Insurance Surcharge"/>
            <ns1:Fee Amount="40.00" CurrencyCode="AED" DecimalPlaces="2" FeeCode="YY/Long Haul Fuel Surcharge"/>
            <ns1:Fee Amount="30.00" CurrencyCode="AED" DecimalPlaces="2" FeeCode="YX-30/Additional Fuel Surcharge"/>
            <ns1:Fee Amount="95.00" CurrencyCode="AED" DecimalPlaces="2" FeeCode="YQ/Fuel Surcharge"/>
            </ns1:Fees>
            <ns1:TotalFare Amount="971.00" CurrencyCode="AED" DecimalPlaces="2"/>
            </ns1:PassengerFare>
            <ns1:TravelerRefNumber RPH="A1"/>
            </ns1:PTC_FareBreakdown>
            </ns1:PTC_FareBreakdowns>
            </ns1:AirItineraryPricingInfo>
            </ns1:PricedItinerary>
            </ns1:PricedItineraries>
            </ns1:AAAirAvailRSExt>
            <ns1:Errors/>
            </ns1:OTA_AirAvailRS>
            </soap:Body>
            </soap:Envelope>'));
        } catch (Exception $e) {
            echo $e->getMessage();
        }
        return;
    }

    public function XMLtoJSON($result)
    {
        $xml = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $result);
        $xml = simplexml_load_string($xml);
        $json = json_encode($xml);
        $responseArray = json_decode($json, true);
        return $responseArray;
    }

    public function hoursandmins($time, $format = '%02d:%02d')
    {
        if ($time < 1) {
            return;
        }
        $hours = floor($time / 60);
        $minutes = ($time % 60);
        return sprintf($format, $hours, $minutes);
    }
}
