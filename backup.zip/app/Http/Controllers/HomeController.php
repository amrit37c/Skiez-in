<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\ApisRequest;
// use GuzzleHttp\Psr7\Request;
use Illuminate\Http\Request;


class HomeController extends BaseController
{

    public function index()
    {
        return view("index");
    }

    public function bookFlights()
    {
        return view('flightBooking');
    }

    public function flightSearch()
    {
        // die("adsasd");
        $from = strtoupper($_GET["flying_from_N"]);
        $to = strtoupper($_GET["flying_to_N"]);
        // echo $_GET["hfFromDate"];
        $date = date('Y-m-d', (strtotime($_GET["departure_date"])));
        $apiRequest = new ApisRequest();
        $request = '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
                <soap:Header>
                <wsse:Security xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" soap:mustUnderstand="1">
                <wsse:UsernameToken xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd" wsu:Id="UsernameToken-17855236">
                <wsse:Username>APISKIEZTRAVEL</wsse:Username>
                <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">STL@5973</wsse:Password>
                </wsse:UsernameToken>
                </wsse:Security>
                </soap:Header>
                <soap:Body xmlns:ns2="http://www.opentravel.org/OTA/2003/05">
                <ns2:OTA_AirAvailRQ EchoToken="11868765275150-1300257933" PrimaryLangID="en-us" SequenceNmbr="1" Target="TEST" TimeStamp="2008-09-25T04:55:27" Version="20061.00">
                <ns2:POS>
                <ns2:Source TerminalID="TestUser/Test Runner">
                <ns2:RequestorID ID="APISKIEZTRAVEL" Type="4"/>
                <ns2:BookingChannel Type="12"/>
                </ns2:Source>
                </ns2:POS>
                <ns2:OriginDestinationInformation>
                <ns2:DepartureDateTime>' . $date . 'T00:00:00</ns2:DepartureDateTime>
                <ns2:OriginLocation LocationCode="' . $from . '"/>
                <ns2:DestinationLocation LocationCode="' . $to . '"/>
                </ns2:OriginDestinationInformation>
                <ns2:TravelerInfoSummary>
                <ns2:AirTravelerAvail>
                <ns2:PassengerTypeQuantity Code="ADT" Quantity="1"/>
                </ns2:AirTravelerAvail>
                </ns2:TravelerInfoSummary>
                </ns2:OTA_AirAvailRQ>
                </soap:Body>
        </soap:Envelope>';
        $result = $apiRequest->callApi('POST', '', $request);
        // print_r(json_encode($result));
        $data = array("result" => $result);
        // print_r(($result));
        return view("flight-search")->with($data);
    }
}
