<!-- Stored in resources/views/child.blade.php -->
@extends('layouts.master')

@section('title', 'Book Flights'. ' | ' .env('APP_NAME'))

@section('content')

<!-- booking part start-->
<section class="booking_part mt-1" style="background: #fff; box-shadow: 0 0 8px #0000001c;">
    <div class="container book_check_sec" style="background-image: none; padding-bottom: 0;">
        <div class="row">

            <div class="col-lg-10">
                <div class="booking_content" style="box-shadow: none; padding: 10px 0px;float: left;">
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="hotel" role="tabpanel" aria-labelledby="hotel-tab">
                            <div class="booking_form">
                                <script src="{{asset('public/bundles/seachengine02b9?v=4242424242424')}}"></script>

                                <form action="" method="post">
                                    <input id="from_wait" value="" type="hidden" />
                                    <input id="to_wait" value="" type="hidden" />
                                    <input type="hidden" name="device_app" id="device_app" value="2" />
                                    <input type="hidden" name="hfFromDate" id="hfFromDate" value="04/12/2020" />
                                    <input type="hidden" name="hfToDate" id="hfToDate" value="" />
                                    <input type="hidden" name="hfTripType" id="hfTripType" value="false" />
                                    <input type="hidden" name="hfAdult" id="hfAdult" value="" />
                                    <input type="hidden" name="hfChild" id="hfChild" value='' />
                                    <input type="hidden" name="hfInfant" id="hfInfant" value='' />
                                    <input type="hidden" name="hfdirect" id="hfdirect" />
                                    <input type="hidden" name="hdn_flying_from" id="hdn_flying_from" value="" />
                                    <input type="hidden" name="hdn_flying_to" id="hdn_flying_to" value="" />
                                    <input type="hidden" name="modify" id="modify" value="1" />

                                    <section class="serchBox">


                                        <div class="searchEng">

                                            <div class="srcformbx mt-0">

                                                <div class="col-6 col-lg-3 lbl swap search_nav_two">
                                                    <strong class="swap">From </strong>
                                                    <input type="text" name="flying_from_N" value="" class="fly-from-input" placeholder="From" id="flying_from_N" onclick="autodiv_from();" autocomplete="off" />
                                                    <b id="Fly_Depart_airport">Airport Name or City Name</b>
                                                    <img src="{{asset('public/img/swap.png')}}" style="cursor:pointer;" onclick="swapfun()" width="31" height="30" alt="Swap" title="Swap">
                                                    <div class="fromtopopup frompopup">
                                                        <label>
                                                            <i class="fa fa-search"></i>
                                                            <input type="text" name="flying_from" class="fly-from-input ac_input" autocomplete="off" placeholder="From" id="flying_from" />
                                                        </label>
                                                        <div class="staticway">
                                                            <h5>Popular Cities</h5>
                                                            <ul>
                                                                <li onclick="setsearhengine('Delhi', 'DEL', 'Indira Gandhi International Airport', 'India', 'IN')">
                                                                    Delhi</li>
                                                                <li onclick="setsearhengine('Bangalore', 'BLR', 'Bengaluru International Airport', 'India', 'IN')">
                                                                    Bangalore</li>
                                                                <li onclick="setsearhengine('Mumbai', 'BOM', 'Chhatrapati Shivaji International Airport', 'India', 'IN')">
                                                                    Mumbai</li>
                                                                <li onclick="setsearhengine('Hyderabad', 'HYD', 'Shamshabad Rajiv Gandhi International Airport', 'India', 'IN')">
                                                                    Hyderabad</li>
                                                                <li onclick="setsearhengine('Kolkata', 'CCU', 'Netaji Subhas Chandra Bose International Airport', 'India', 'IN')">
                                                                    Kolkata</li>
                                                                <li onclick="setsearhengine('Chennai', 'MAA', 'Chennai Airport', 'India', 'IN')">
                                                                    Chennai/Madras</li>
                                                                <li onclick="setsearhengine('Ahmedabad', 'AMD', 'Ahmedabad International Airport', 'India', 'IN')">
                                                                    Ahmedabad</li>
                                                                <li onclick="setsearhengine('Pune', 'PNQ', 'Lohegaon Airport', 'India', 'IN')">
                                                                    Pune</li>
                                                                <li onclick="setsearhengine('Guwahati', 'GAU', 'Bordoloi International Airport', 'India', 'IN')">
                                                                    Guwahati</li>
                                                                <li onclick="setsearhengine('Goa', 'GOI', 'Dabolim Airport', 'India', 'IN')">
                                                                    Goa</li>
                                                                <li onclick="setsearhengine('Lucknow', 'LKO', 'Amausi Airport', 'India', 'IN')">
                                                                    Lucknow</li>
                                                                <li onclick="setsearhengine('Bhubaneswar', 'BBI', 'Biju Patnaik Airport', 'India', 'IN')">
                                                                    Bhubaneswar</li>
                                                                <li onclick="setsearhengine('Cochin', 'COK', 'Chochin International Airport', 'India', 'IN')">
                                                                    Cochin</li>
                                                                <li onclick="setsearhengine('Jaipur', 'JAI', 'Sanganeer Airport', 'India', 'IN')">
                                                                    Jaipur</li>
                                                                <li onclick="setsearhengine('Patna', 'PAT', 'Jai Prakash Narayan Airport', 'India', 'IN')">
                                                                    Patna</li>
                                                                <li onclick="setsearhengine('Srinagar', 'SXR', 'Srinagar International Airport', 'India', 'IN')">
                                                                    Srinagar</li>
                                                                <li onclick="setsearhengine('Nagpur', 'NAG', 'Dr Ambedkar International Airport', 'India', 'IN')">
                                                                    Nagpur</li>
                                                                <li onclick="setsearhengine('Agartala', 'IXA', 'Singerbhil Airport', 'India', 'IN')">
                                                                    Agartala</li>
                                                            </ul>
                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="col-6 col-lg-3 lbl search_nav_two">

                                                    <strong>To</strong>
                                                    <input name="flying_to_N" type="text" class="fly-to-input" value="" placeholder="To" id="flying_to_N" onclick="autodiv_to();" autocomplete="off" />
                                                    <b id="Fly_Dest_airport">Airport Name or City Name</b>

                                                    <div class="fromtopopup topopup">
                                                        <label>
                                                            <i class="fa fa-search"></i>

                                                            <input type="text" name="flying_to" class="fly-from-input ac_input" autocomplete="off" placeholder="To" id="flying_to" />
                                                        </label>
                                                        <div class="staticway">
                                                            <h5>Popular Cities</h5>
                                                            <ul>
                                                                <li onclick="setsearhengine_Return('Delhi', 'DEL', 'Indira Gandhi International Airport', 'India', 'IN')">
                                                                    Delhi</li>
                                                                <li onclick="setsearhengine_Return('Bangalore', 'BLR', 'Bengaluru International Airport', 'India', 'IN')">
                                                                    Bangalore</li>
                                                                <li onclick="setsearhengine_Return('Mumbai', 'BOM', 'Chhatrapati Shivaji International Airport', 'India', 'IN')">
                                                                    Mumbai</li>
                                                                <li onclick="setsearhengine_Return('Hyderabad', 'HYD', 'Shamshabad Rajiv Gandhi International Airport', 'India', 'IN')">
                                                                    Hyderabad</li>
                                                                <li onclick="setsearhengine_Return('Kolkata', 'CCU', 'Netaji Subhas Chandra Bose International Airport', 'India', 'IN')">
                                                                    Kolkata</li>
                                                                <li onclick="setsearhengine_Return('Chennai', 'MAA', 'Chennai Airport', 'India', 'IN')">
                                                                    Chennai/Madras</li>
                                                                <li onclick="setsearhengine_Return('Ahmedabad', 'AMD', 'Ahmedabad International Airport', 'India', 'IN')">
                                                                    Ahmedabad</li>
                                                                <li onclick="setsearhengine_Return('Pune', 'PNQ', 'Lohegaon Airport', 'India', 'IN')">
                                                                    Pune</li>
                                                                <li onclick="setsearhengine_Return('Guwahati', 'GAU', 'Bordoloi International Airport', 'India', 'IN')">
                                                                    Guwahati</li>
                                                                <li onclick="setsearhengine_Return('Goa', 'GOI', 'Dabolim Airport', 'India', 'IN')">
                                                                    Goa</li>
                                                                <li onclick="setsearhengine_Return('Lucknow', 'LKO', 'Amausi Airport', 'India', 'IN')">
                                                                    Lucknow</li>
                                                                <li onclick="setsearhengine_Return('Bhubaneswar', 'BBI', 'Biju Patnaik Airport', 'India', 'IN')">
                                                                    Bhubaneswar</li>
                                                                <li onclick="setsearhengine_Return('Cochin', 'COK', 'Chochin International Airport', 'India', 'IN')">
                                                                    Cochin</li>
                                                                <li onclick="setsearhengine_Return('Jaipur', 'JAI', 'Sanganeer Airport', 'India', 'IN')">
                                                                    Jaipur</li>
                                                                <li onclick="setsearhengine_Return('Patna', 'PAT', 'Jai Prakash Narayan Airport', 'India', 'IN')">
                                                                    Patna</li>
                                                                <li onclick="setsearhengine_Return('Srinagar', 'SXR', 'Srinagar International Airport', 'India', 'IN')">
                                                                    Srinagar</li>
                                                                <li onclick="setsearhengine_Return('Nagpur', 'NAG', 'Dr Ambedkar International Airport', 'India', 'IN')">
                                                                    Nagpur</li>
                                                                <li onclick="setsearhengine_Return('Agartala', 'IXA', 'Singerbhil Airport', 'India', 'IN')">
                                                                    Agartala</li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-6 col-lg-2 lbl search_nav_two" id="Fly_dep_datepickerid">
                                                    <strong>Departure <i class="fa fa-angle-down"></i></strong>
                                                    <input id="datepicker_1" placeholder="00/00/0000" style="font-size: 20px;margin-top: 19px;">
                                                </div>
                                                <div class="col-6 col-lg-2 lbl search_nav_two" onclick="return SelectTripType('R')" id="Fly_ret_datepickerid" disabled="disabled" style="cursor: no-drop; background: #f5f2f2; ">
                                                    <strong>Return <i class="fa fa-angle-down"></i></strong>
                                                    <input id="datepicker_2" placeholder="00/00/0000" style="font-size: 20px;margin-top: 19px;">
                                                </div>
                                                <div class="col-12 col-lg-2 lbl search_nav_two lst" id="adult_div">
                                                    <input type="hidden" id="adult" name="adult" value="1" />
                                                    <strong>Travellers & Class <i class="fa fa-angle-down"></i></strong>
                                                    <span><big id="travel_id">1</big> Traveller</span>
                                                    <b id="cabin_id">Economy</b>

                                                </div>

                                                <div class="popup adultdrop">
                                                    <span class="adult1">
                                                        <span class="ad_left">
                                                            <img src="{{asset('public/img/adult.png')}}" alt="Adult Flights">
                                                            Adults (12+)
                                                        </span> <span class="ad_right">
                                                            <input type="button" class="minus maincalulation" value="-" id="sub1minus">
                                                            <input type="text" class="count" value="1" id="sub1">
                                                            <input type="button" class="plus maincalulation" value="+" id="sub1plus">
                                                        </span>
                                                    </span>
                                                    <span class="adult1">
                                                        <span class="ad_left">
                                                            <img src="{{asset('public/img/child.png')}}" alt="Child Flights">
                                                            Children (2-11)
                                                        </span>
                                                        <span class="ad_right">
                                                            <input type="button" class="minus maincalulation" value="-" id="sub2minus">
                                                            <input type="text" class="count" value="0" id="sub2">
                                                            <input type="button" class="plus maincalulation" value="+" id="sub2plus">
                                                        </span>
                                                    </span>
                                                    <span class="adult1">
                                                        <span class="ad_left">
                                                            <img src="{{asset('public/img/infant.png')}}" alt="Infant Flights">
                                                            Infant
                                                        </span>
                                                        <span class="ad_right">
                                                            <input type="button" class="minus maincalulation" value="-" id="sub3minus">
                                                            <input type="text" class="count" value="0" id="sub3">
                                                            <input type="button" class="plus maincalulation" value="+" id="sub3plus">
                                                        </span>
                                                    </span>
                                                    <div>
                                                        <span>&nbsp;</span>
                                                        <span>Choose Travel Class</span>
                                                    </div>
                                                    <div class="search-sixbox">
                                                        <select name="ddlCabinClass" id="ddlCabinClass" onchange="getval_Cabin();" class=" fly-cabin-input ac_input">
                                                            <option value="2" selected="selected">Economy</option>
                                                            <option value="3">Premium Economy</option>
                                                            <option value="4">Business</option>
                                                            <option value="6">First</option>
                                                        </select>

                                                        <div class="search-eightbox" style="display:none;">
                                                            <div class="custom-control custom-checkbox pt-2 text-left">
                                                                <input type="checkbox" id="chkIsDirect" class="custom-control-input">
                                                                <label class="custom-control-label" for="chkIsDirect">Direct
                                                                    Flight</label>
                                                            </div>
                                                        </div>

                                                    </div>
                                                    <span class="done"><a>Done</a></span>

                                                </div>

                                            </div>
                                        </div>

                                    </section>
                                    <style>
                                        .fromtopopup {
                                            display: none;
                                            width: 340px;
                                            position: absolute;
                                            left: 0;
                                            top: 30px;
                                            float: left;
                                            -webkit-border-radius: 4px;
                                            -moz-border-radius: 4px;
                                            border-radius: 4px;
                                            background-color: #ffffff;
                                            -webkit-box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.2);
                                            -moz-box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.2);
                                            box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.2);
                                            z-index: 9999;
                                        }

                                        .fromtopopup label {
                                            width: 100%;
                                            position: relative;
                                            min-height: auto;
                                        }

                                        .fromtopopup label i {
                                            position: absolute;
                                            left: 10px;
                                            top: 15px;
                                            font-size: 12px;
                                        }

                                        .fromtopopup p {
                                            color: #666;
                                            font-size: 13px;
                                            padding: 0px 10px;
                                        }

                                        .fromtopopup input {
                                            width: 100% !important;
                                            background: #ffffff !important;
                                            -webkit-box-shadow: 0 2px 3px 0 rgba(204, 204, 204, 0.1);
                                            -moz-box-shadow: 0 2px 3px 0 rgba(204, 204, 204, 0.1);
                                            box-shadow: 0 2px 3px 0 rgba(204, 204, 204, 0.1);
                                            padding: 11px 10px 11px 30px;
                                            outline: 0;
                                            border: 0;
                                            width: 100%;
                                            font-size: 15px !important;
                                            color: #666;
                                            font-weight: normal !important;
                                        }

                                        .fromtopopup input:focus {
                                            outline: 0;
                                            border: 0;
                                        }
                                    </style>
                                </form>
                                <script src="{{asset('public/bundles/autocomplate41de?v=12342424d23424567fffsss')}}"></script>

                            </div>

                        </div>


                    </div>
                </div>
            </div>

            <div class="col-lg-2">
                <h6 class="total_paid_ammount">Total Ammount to be Paid <span>₹ 6,845</span></h6>
            </div>

        </div>
    </div>
</section>
<!-- Header part end-->


<section class="refine_result">
    <div class="container">
        <div class="row">
            <div class="refine_rslt_row refine_rslt_form refine_rslt_form_active">
                <a href="#"><span>1</span> Travellers' Details <i class="fas fa-caret-right"></i></a>
            </div>

            <div class="refine_rslt_row refine_rslt_form">
                <a href="#"><span>2</span> Review Itinerary <i class="fas fa-caret-right"></i></a>
            </div>

            <div class="refine_rslt_row refine_rslt_form">
                <a href="#"><span>3</span> Make Payment<i class="fas fa-caret-right"></i></a>
            </div>
        </div>
    </div>
</section>




<section class="result_search_flights">
    <div class="container">
        <div class="row">
            <div class="col-md-10 mx-auto">
                <div class="row book_formsec_1">
                    <div class="col-md-12 book_formtop_info">
                        <p><i class="fas fa-info-circle"></i> Please make sure the details entered below are exactly as per Traveller's ID</p>
                    </div>

                    <div class="col-md-12 book_formsec_form_top_head">
                        <h5>MR. <span>Above 12 years</span></h5>
                    </div>

                    <div class="col-md-2 book_form_detail">
                        <label for="">Title</label>
                        <select name="" id="">
                            <option value="">Mr</option>
                            <option value="">Mrs</option>
                            <option value="">Miss</option>
                        </select>
                    </div>

                    <div class="col-md-5 book_form_detail_two">
                        <label for="">First Name / Given Name</label>
                        <input type="text" placeholder="First Name" />
                    </div>

                    <div class="col-md-5 book_form_detail_two">
                        <label for="">Last Name / Surname</label>
                        <input type="text" placeholder="Last Name" />
                    </div>

                    <div class="col-md-2">
                    </div>

                    <div class="col-md-5 book_form_detail_three mt-1">
                        <label for="">Date of Birth</label>
                        <select name="" id="">
                            <option value="">Day</option>
                            <option value="">1</option>
                            <option value="">2</option>
                            <option value="">3</option>
                            <option value="">4</option>
                        </select>

                        <select name="" id="">
                            <option value="">Month</option>
                            <option value="">Jan</option>
                            <option value="">Feb</option>
                            <option value="">March</option>
                            <option value="">April</option>
                        </select>

                        <select name="" id="">
                            <option value="">Year</option>
                            <option value="">2021</option>
                            <option value="">2020</option>
                            <option value="">2019</option>
                            <option value="">2018</option>
                        </select>
                    </div>

                    <div class="col-md-5">
                    </div>


                    <div class="col-md-12">
                        <p class="show_more_btn_booking_form"><button><i class="fas fa-sort-down"></i> Show more options</button> ( Meal, Baggage, frequent Flyer Number etc)</p>

                        <div class="booking_form_show_sec">

                            <div class="booking_form_show_sec_one">
                                <h1>Select Meals</h1>

                                <div class="booking_form_show_sec_under">
                                    <label>DEL-BOM</label>
                                    <select name="" id="">
                                        <option value="">No Meal</option>
                                        <option value="">No Meal</option>
                                    </select>
                                </div>
                            </div>


                            <div class="booking_form_show_sec_one">
                                <h1>Select extra baggage</h1>

                                <div class="booking_form_show_sec_under">
                                    <label>DEL-BOM</label>
                                    <select name="" id="">
                                        <option value="">No Baggage</option>
                                        <option value="">No Baggage</option>
                                    </select>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>


                <div class="row book_formsec_1">
                    <div class="col-md-12 book_formsec_form_top_head_two">
                        <h5>Select Seats (Optional)</h5>
                    </div>

                    <div class="col-md-12 book_formtop_info book_formtop_info_two">
                        <p><i class="fas fa-info-circle"></i> The final seat allocation is subject to availability</p>
                    </div>

                    <div class="col-md-4 mx-auto select_ae_seat">
                        <h6><i class="fas fa-plane"></i> Sel onward seat</h6>

                        <h5>Flight 1 <span>BOM-GOI <strong>15-1335</strong></span></h5>

                        <p>Seat Selected: <span>No Seat Selected</span></p>


                        <h6><i class="fas fa-plane"></i> Sel onward seat</h6>

                        <h5>Flight 2 <span>BOM-GOI <strong>15-1335</strong></span></h5>

                        <p>Seat Selected: <span>No Seat Selected</span></p>
                    </div>
                </div>


                <div class="row book_formsec_1">
                    <div class="col-md-12 book_formtop_info">
                        <p><i class="fas fa-info-circle"></i> Your Ticket will be sent to this email address</p>
                    </div>

                    <div class="col-md-6 book_form_detail_two book_form_detail_two_si my-4">
                        <label for="">Mobile</label>

                        <select name="" id="">
                            <option value="">+91</option>
                            <option value="">+92</option>
                            <option value="">+93</option>
                        </select>

                        <input type="text" placeholder="Mobile" />
                    </div>

                    <div class="col-md-6 book_form_detail_two my-4">
                        <label for="">Email</label>
                        <input type="text" placeholder="Email" />
                    </div>

                </div>

                <div class="row book_formsec_1">
                    <div class="col-md-12 book_formtop_info">
                        <p><i class="fas fa-info-circle"></i> Insurance fee as applicable will be added if you select yes and proceed. Read terms & conditions for more informations</p>
                    </div>

                    <div class="col-md-12 check_sec_booking_form my-4">
                        <input type="checkbox" value="" checked>
                        <p>Add Travel Insurance - Safeguard your travel & yourself @ <span>₹133</span> (Per Passenger)</p>
                    </div>

                </div>

                <div class="row book_formsec_1">
                    <div class="col-md-12 check_sec_booking_form check_sec_booking_form_two my-4">
                        <input type="checkbox" value="" checked>
                        <p>I have Read and Agree to the <a href="#">Terms & Condition</a></p>
                        <button onclick="window.location.href='book_flight_review_iternerary.html'" class="proceed_booking_btn">Proceed to Booking</button>
                    </div>

                </div>
            </div>

        </div>
    </div>
</section>


@endsection