@extends('layouts.master')

@section('title', 'About Us' . ' | ' . env('APP_NAME'))

@section('content')
<!--top place start-->
<section class="section_padding">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6">
                <div class="section_tittle section_tittle_top text-center">
                    <h2>About <span>Us</span></h2>
                    <p>Lorem ipsum dolor sit amet, id altera persequeris vim, mea an appareat prodesset</p>
                </div>
            </div>
        </div>

    </div>
</section>
<!--top place end-->

<section class="">
    <div class="container">
        <div class="row">
            <div class="col-md-6 pt-5 mt-5">
                <h2>The Process </h2>
                <h1><strong class="mb-5">About Our Work</strong></h1>

                <p class="mt-3">Lorem ipsum dolor sit amet, vel accumsan liberavisse ex, ea nec
                    elaboraret interpretaris, sed diceret concludaturque ndo. Verear
                    habemus sea ut. His nibh scripta in. In sea vocibus facilisis. Sed</p>

                <p>vel cu paulo doctus vidisse. Iudico dicant nostrum nec an, in eos
                    In detraxit eleifend duo, alterum iudicabit consectetuer per ad.</p>
            </div>

            <div class="col-md-6 ">
                <img src="{{asset('public/img/about_right.png')}}" />
            </div>
        </div>
    </div>
</section>

<section class="abour_subs">
    <div class="container">
        <div class="row">
            <div class="col-md-7 ">
                <img src="{{asset('public/img/always_help.png')}}" style="width: 90% !important;" />
            </div>

            <div class="col-md-5 pt-4">
                <h2>We are here to </h2>
                <h1><strong class="mb-5">always help</strong> you</h1>

                <p class="mt-3">Lorem ipsum dolor sit amet, vel accumsan liberavisse ex, a
                    elaboraret interpretaris, sed diceret concludaturque nasdo
                    habemus sea ut. His nibh scripta in. In sea vocibus facilisis.</p>

                <p>vel cu paulo doctus vidsse. Iudico dicant nostrum nec aIn
                    detraxit eleifend duo, alterum iudicabit consectetuer per.</p>


                <div class="about_email_subs">
                    <input type="text" placeholder="Enter your email">
                    <button href="#" class="btn_1  d-lg-block">SUBSCRIBE</button>
                </div>
            </div>

        </div>
    </div>
</section>


<!--top place start-->
<section class="client_review section_padding" style="background-color: #fff;">
    <div class="container">
        <div class="row ">
            <div class="col-xl-12">
                <div class="about_slider">
                    <h3>What is the</h2>
                        <h2><strong>Speciality Of Us?</strong></h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="client_review_slider owl-carousel">
                    <div class="single_review_slider about_single_review_slider">
                        <img src="{{asset('public/img/about_slide_1.png')}}" />
                        <h2>Quick <strong>Response</strong></h2>
                        <p>Lorem ipsum dolor sit amet, vel accumsan liberavisse ex, ea nec concludaturque ndo.
                            Verear</p>
                    </div>

                    <div class="single_review_slider about_single_review_slider">
                        <img src="{{asset('public/img/about_slide_2.png')}}" />
                        <h2>Great <strong>Communication</strong></h2>
                        <p>Lorem ipsum dolor sit amet, vel accumsan liberavisse ex, ea nec concludaturque ndo.
                            Verear</p>
                    </div>

                    <div class="single_review_slider about_single_review_slider">
                        <img src="{{asset('public/img/about_slide_3.png')}}" />
                        <h2>Customer <strong>Satisfaction</strong></h2>
                        <p>Lorem ipsum dolor sit amet, vel accumsan liberavisse ex, ea nec concludaturque ndo.
                            Verear</p>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
<!--top place end-->

@endsection