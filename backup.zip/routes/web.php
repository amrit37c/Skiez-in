<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'HomeController@index')->name('home');

Route::get('/about-us', function(){
    return view("about");
})->name("about");

Route::get("/flight-booking", function(){
    return view("flights-booking");
})->name("flightBooking");

Route::get("/hotel-booking", function(){
    return view("hotel-booking");
})->name("hotelBooking");

Route::get("/packages", function(){
    return view("flights-booking");
})->name("packages");

Route::get("/search-flights", "HomeController@flightSearch")->name("searchFlight");

Route::get("/test", 'HomeController@testAPi');