<!-- Stored in resources/views/child.blade.php -->


<?php $__env->startSection('title', 'Home' . ' | ' . env('APP_NAME')); ?>

<?php $__env->startSection('content'); ?>
<!-- booking part start-->
<section class="booking_part mt-1" style="background: #fff; box-shadow: 0 0 8px #0000001c;">
    <div class="container book_check_sec" style="background-image: none; padding-bottom: 0;">
        <div class="row">

            <div class="col-lg-10">
                <div class="booking_content booking_content_cstm1" style="box-shadow: none; padding: 10px 0px;float: left;">
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="hotel" role="tabpanel" aria-labelledby="hotel-tab">
                            <div class="booking_form">
                                <script src="bundles/seachengine02b9?v=4242424242424"></script>

                                <form action="" method="post">
                                    <input id="from_wait" value="" type="hidden" />
                                    <input id="to_wait" value="" type="hidden" />
                                    <input type="hidden" name="device_app" id="device_app" value="2" />
                                    <input type="hidden" name="hfFromDate" id="hfFromDate" value="04/12/2020" />
                                    <input type="hidden" name="hfToDate" id="hfToDate" value="" />
                                    <input type="hidden" name="hfTripType" id="hfTripType" value="false" />
                                    <input type="hidden" name="hfAdult" id="hfAdult" value="" />
                                    <input type="hidden" name="hfChild" id="hfChild" value='' />
                                    <input type="hidden" name="hfInfant" id="hfInfant" value='' />
                                    <input type="hidden" name="hfdirect" id="hfdirect" />
                                    <input type="hidden" name="hdn_flying_from" id="hdn_flying_from" value="" />
                                    <input type="hidden" name="hdn_flying_to" id="hdn_flying_to" value="" />
                                    <input type="hidden" name="modify" id="modify" value="1" />

                                    <section class="serchBox">


                                        <div class="searchEng">

                                            <div class="srcformbx mt-0">

                                                <div class="col-6 col-lg-3 lbl swap search_nav_two">
                                                    <strong class="swap">From </strong>
                                                    <input type="text" name="flying_from_N" value="<?= $_GET["flying_from_N"] ?>" class="fly-from-input" placeholder="From" id="flying_from_N" onclick="autodiv_from();" autocomplete="off" />
                                                    <b id="Fly_Depart_airport">Airport Name or City Name</b>
                                                    <img src="img/swap.png" style="cursor:pointer;" onclick="swapfun()" width="31" height="30" alt="Swap" title="Swap">
                                                    <div class="fromtopopup frompopup">
                                                        <label>
                                                            <i class="fa fa-search"></i>
                                                            <input type="text" name="flying_from" class="fly-from-input ac_input" autocomplete="off" placeholder="From" id="flying_from" />
                                                        </label>
                                                        <div class="staticway">
                                                            <h5>Popular Cities</h5>
                                                            <ul>
                                                                <li onclick="setsearhengine('Delhi', 'DEL', 'Indira Gandhi International Airport', 'India', 'IN')">
                                                                    Delhi</li>
                                                                <li onclick="setsearhengine('Bangalore', 'BLR', 'Bengaluru International Airport', 'India', 'IN')">
                                                                    Bangalore</li>
                                                                <li onclick="setsearhengine('Mumbai', 'BOM', 'Chhatrapati Shivaji International Airport', 'India', 'IN')">
                                                                    Mumbai</li>
                                                                <li onclick="setsearhengine('Hyderabad', 'HYD', 'Shamshabad Rajiv Gandhi International Airport', 'India', 'IN')">
                                                                    Hyderabad</li>
                                                                <li onclick="setsearhengine('Kolkata', 'CCU', 'Netaji Subhas Chandra Bose International Airport', 'India', 'IN')">
                                                                    Kolkata</li>
                                                                <li onclick="setsearhengine('Chennai', 'MAA', 'Chennai Airport', 'India', 'IN')">
                                                                    Chennai/Madras</li>
                                                                <li onclick="setsearhengine('Ahmedabad', 'AMD', 'Ahmedabad International Airport', 'India', 'IN')">
                                                                    Ahmedabad</li>
                                                                <li onclick="setsearhengine('Pune', 'PNQ', 'Lohegaon Airport', 'India', 'IN')">
                                                                    Pune</li>
                                                                <li onclick="setsearhengine('Guwahati', 'GAU', 'Bordoloi International Airport', 'India', 'IN')">
                                                                    Guwahati</li>
                                                                <li onclick="setsearhengine('Goa', 'GOI', 'Dabolim Airport', 'India', 'IN')">
                                                                    Goa</li>
                                                                <li onclick="setsearhengine('Lucknow', 'LKO', 'Amausi Airport', 'India', 'IN')">
                                                                    Lucknow</li>
                                                                <li onclick="setsearhengine('Bhubaneswar', 'BBI', 'Biju Patnaik Airport', 'India', 'IN')">
                                                                    Bhubaneswar</li>
                                                                <li onclick="setsearhengine('Cochin', 'COK', 'Chochin International Airport', 'India', 'IN')">
                                                                    Cochin</li>
                                                                <li onclick="setsearhengine('Jaipur', 'JAI', 'Sanganeer Airport', 'India', 'IN')">
                                                                    Jaipur</li>
                                                                <li onclick="setsearhengine('Patna', 'PAT', 'Jai Prakash Narayan Airport', 'India', 'IN')">
                                                                    Patna</li>
                                                                <li onclick="setsearhengine('Srinagar', 'SXR', 'Srinagar International Airport', 'India', 'IN')">
                                                                    Srinagar</li>
                                                                <li onclick="setsearhengine('Nagpur', 'NAG', 'Dr Ambedkar International Airport', 'India', 'IN')">
                                                                    Nagpur</li>
                                                                <li onclick="setsearhengine('Agartala', 'IXA', 'Singerbhil Airport', 'India', 'IN')">
                                                                    Agartala</li>
                                                            </ul>
                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="col-6 col-lg-3 lbl search_nav_two">

                                                    <strong>To</strong>
                                                    <input name="flying_to_N" type="text" class="fly-to-input" value="<?= $_GET["flying_to_N"] ?>" placeholder="To" id="flying_to_N" onclick="autodiv_to();" autocomplete="off" />
                                                    <b id="Fly_Dest_airport">Airport Name or City Name</b>

                                                    <div class="fromtopopup topopup">
                                                        <label>
                                                            <i class="fa fa-search"></i>

                                                            <input type="text" name="flying_to" class="fly-from-input ac_input" autocomplete="off" placeholder="To" id="flying_to" />
                                                        </label>
                                                        <div class="staticway">
                                                            <h5>Popular Cities</h5>
                                                            <ul>
                                                                <li onclick="setsearhengine_Return('Delhi', 'DEL', 'Indira Gandhi International Airport', 'India', 'IN')">
                                                                    Delhi</li>
                                                                <li onclick="setsearhengine_Return('Bangalore', 'BLR', 'Bengaluru International Airport', 'India', 'IN')">
                                                                    Bangalore</li>
                                                                <li onclick="setsearhengine_Return('Mumbai', 'BOM', 'Chhatrapati Shivaji International Airport', 'India', 'IN')">
                                                                    Mumbai</li>
                                                                <li onclick="setsearhengine_Return('Hyderabad', 'HYD', 'Shamshabad Rajiv Gandhi International Airport', 'India', 'IN')">
                                                                    Hyderabad</li>
                                                                <li onclick="setsearhengine_Return('Kolkata', 'CCU', 'Netaji Subhas Chandra Bose International Airport', 'India', 'IN')">
                                                                    Kolkata</li>
                                                                <li onclick="setsearhengine_Return('Chennai', 'MAA', 'Chennai Airport', 'India', 'IN')">
                                                                    Chennai/Madras</li>
                                                                <li onclick="setsearhengine_Return('Ahmedabad', 'AMD', 'Ahmedabad International Airport', 'India', 'IN')">
                                                                    Ahmedabad</li>
                                                                <li onclick="setsearhengine_Return('Pune', 'PNQ', 'Lohegaon Airport', 'India', 'IN')">
                                                                    Pune</li>
                                                                <li onclick="setsearhengine_Return('Guwahati', 'GAU', 'Bordoloi International Airport', 'India', 'IN')">
                                                                    Guwahati</li>
                                                                <li onclick="setsearhengine_Return('Goa', 'GOI', 'Dabolim Airport', 'India', 'IN')">
                                                                    Goa</li>
                                                                <li onclick="setsearhengine_Return('Lucknow', 'LKO', 'Amausi Airport', 'India', 'IN')">
                                                                    Lucknow</li>
                                                                <li onclick="setsearhengine_Return('Bhubaneswar', 'BBI', 'Biju Patnaik Airport', 'India', 'IN')">
                                                                    Bhubaneswar</li>
                                                                <li onclick="setsearhengine_Return('Cochin', 'COK', 'Chochin International Airport', 'India', 'IN')">
                                                                    Cochin</li>
                                                                <li onclick="setsearhengine_Return('Jaipur', 'JAI', 'Sanganeer Airport', 'India', 'IN')">
                                                                    Jaipur</li>
                                                                <li onclick="setsearhengine_Return('Patna', 'PAT', 'Jai Prakash Narayan Airport', 'India', 'IN')">
                                                                    Patna</li>
                                                                <li onclick="setsearhengine_Return('Srinagar', 'SXR', 'Srinagar International Airport', 'India', 'IN')">
                                                                    Srinagar</li>
                                                                <li onclick="setsearhengine_Return('Nagpur', 'NAG', 'Dr Ambedkar International Airport', 'India', 'IN')">
                                                                    Nagpur</li>
                                                                <li onclick="setsearhengine_Return('Agartala', 'IXA', 'Singerbhil Airport', 'India', 'IN')">
                                                                    Agartala</li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-6 col-lg-2 lbl search_nav_two" id="Fly_dep_datepickerid">
                                                    <strong>Departure <i class="fa fa-angle-down"></i></strong>
                                                    <input id="datepicker_1" name="departure_date" value="<?= $_GET["departure_date"] ?>" placeholder="00/00/0000" style="font-size: 20px;margin-top: 19px;">
                                                </div>
                                                <div class="col-6 col-lg-2 lbl search_nav_two" onclick="return SelectTripType('R')" id="Fly_ret_datepickerid" disabled="disabled" style="cursor: no-drop; background: #f5f2f2; ">
                                                    <strong>Return <i class="fa fa-angle-down"></i></strong>
                                                    <input id="datepicker_2" name="return_date" value="<?= $_GET["return_date"] ?>" placeholder="00/00/0000" style="font-size: 20px;margin-top: 19px;">
                                                </div>
                                                <div class="col-12 col-lg-2 lbl search_nav_two lst" id="adult_div">
                                                    <input type="hidden" id="adult" name="adult" value="1" />
                                                    <strong>Travellers & Class <i class="fa fa-angle-down"></i></strong>
                                                    <span><big id="travel_id">1</big> Traveller</span>
                                                    <b id="cabin_id">Economy</b>

                                                </div>

                                                <div class="popup adultdrop">
                                                    <span class="adult1">
                                                        <span class="ad_left">
                                                            <img src="img/adult.png" alt="Adult Flights">
                                                            Adults (12+)
                                                        </span> <span class="ad_right">
                                                            <input type="button" class="minus maincalulation" value="-" id="sub1minus">
                                                            <input type="text" class="count" value="1" id="sub1">
                                                            <input type="button" class="plus maincalulation" value="+" id="sub1plus">
                                                        </span>
                                                    </span>
                                                    <span class="adult1">
                                                        <span class="ad_left">
                                                            <img src="img/child.png" alt="Child Flights">
                                                            Children (2-11)
                                                        </span>
                                                        <span class="ad_right">
                                                            <input type="button" class="minus maincalulation" value="-" id="sub2minus">
                                                            <input type="text" class="count" value="0" id="sub2">
                                                            <input type="button" class="plus maincalulation" value="+" id="sub2plus">
                                                        </span>
                                                    </span>
                                                    <span class="adult1">
                                                        <span class="ad_left">
                                                            <img src="img/infant.png" alt="Infant Flights">
                                                            Infant
                                                        </span>
                                                        <span class="ad_right">
                                                            <input type="button" class="minus maincalulation" value="-" id="sub3minus">
                                                            <input type="text" class="count" value="0" id="sub3">
                                                            <input type="button" class="plus maincalulation" value="+" id="sub3plus">
                                                        </span>
                                                    </span>
                                                    <div>
                                                        <span>&nbsp;</span>
                                                        <span>Choose Travel Class</span>
                                                    </div>
                                                    <div class="search-sixbox">
                                                        <select name="ddlCabinClass" id="ddlCabinClass" onchange="getval_Cabin();" class=" fly-cabin-input ac_input">
                                                            <option value="2" selected="selected">Economy</option>
                                                            <option value="3">Premium Economy</option>
                                                            <option value="4">Business</option>
                                                            <option value="6">First</option>
                                                        </select>

                                                        <div class="search-eightbox" style="display:none;">
                                                            <div class="custom-control custom-checkbox pt-2 text-left">
                                                                <input type="checkbox" id="chkIsDirect" class="custom-control-input">
                                                                <label class="custom-control-label" for="chkIsDirect">Direct
                                                                    Flight</label>
                                                            </div>
                                                        </div>

                                                    </div>
                                                    <span class="done"><a>Done</a></span>

                                                </div>

                                            </div>
                                        </div>

                                    </section>
                                    <style>
                                        .fromtopopup {
                                            display: none;
                                            width: 340px;
                                            position: absolute;
                                            left: 0;
                                            top: 30px;
                                            float: left;
                                            -webkit-border-radius: 4px;
                                            -moz-border-radius: 4px;
                                            border-radius: 4px;
                                            background-color: #ffffff;
                                            -webkit-box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.2);
                                            -moz-box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.2);
                                            box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.2);
                                            z-index: 9999;
                                        }

                                        .fromtopopup label {
                                            width: 100%;
                                            position: relative;
                                            min-height: auto;
                                        }

                                        .fromtopopup label i {
                                            position: absolute;
                                            left: 10px;
                                            top: 15px;
                                            font-size: 12px;
                                        }

                                        .fromtopopup p {
                                            color: #666;
                                            font-size: 13px;
                                            padding: 0px 10px;
                                        }

                                        .fromtopopup input {
                                            width: 100% !important;
                                            background: #ffffff !important;
                                            -webkit-box-shadow: 0 2px 3px 0 rgba(204, 204, 204, 0.1);
                                            -moz-box-shadow: 0 2px 3px 0 rgba(204, 204, 204, 0.1);
                                            box-shadow: 0 2px 3px 0 rgba(204, 204, 204, 0.1);
                                            padding: 11px 10px 11px 30px;
                                            outline: 0;
                                            border: 0;
                                            width: 100%;
                                            font-size: 15px !important;
                                            color: #666;
                                            font-weight: normal !important;
                                        }

                                        .fromtopopup input:focus {
                                            outline: 0;
                                            border: 0;
                                        }
                                    </style>
                                </form>
                                <script src="bundles/autocomplate41de?v=12342424d23424567fffsss"></script>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-2">
                <a href="#" class="btn_1 d-lg-block refine_btn"><i class="fas fa-filter"></i> Refine Results</a>
            </div>

        </div>
    </div>
</section>
<!-- Header part end-->

<section class="refine_result">
    <div class="container">
        <div class="row">

            <div class="refine_rslt_row">
                <h2><i class="fas fa-rupee-sign"></i> Price</h2>
                <span>
                    <p>₹5,608 - ₹16085</p>
                </span> <button><i class="fas fa-sort-down"></i></button>
            </div>

            <div class="refine_rslt_row">
                <h2><i class="fas fa-map-marker-alt"></i> Stops</h2>
                <span>
                    <p>2 Stops</p>
                </span> <button><i class="fas fa-sort-down"></i></button>
            </div>

            <div class="refine_rslt_row">
                <h2><i class="far fa-clock"></i> Times</h2>
                <span>
                    <p>All Times</p>
                </span> <button><i class="fas fa-sort-down"></i></button>
            </div>

            <div class="refine_rslt_row">
                <h2><i class="fas fa-star"></i> Itineraries</h2>
                <span>
                    <p>All Itineraries</p>
                </span> <button><i class="fas fa-sort-down"></i></button>
            </div>

            <div class="clear_refine_rslt_btn">
                <button><i class="fas fa-redo-alt"></i>

                    Clear Filters</button>
            </div>


        </div>
    </div>
</section>

<section class="result_search_flights">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="result_number">
                    <p>189 Flight Results</p>
                    <span>
                        <button>Previous Day</button>
                        <button>Next Day</button>
                    </span>
                </div>
            </div>

            <div class="col-md-12">
                <div class="select_flight">
                    <p>Select onward flights</p>
                    <span>
                        <p>Sort By </p>
                        <button>Price - Low <i class="fas fa-sort-down"></i></button>
                    </span>
                </div>
            </div>
        </div>

        <div class="row mt-4 mb-4">
            <?php
            // echo $result;
            $flightsResult = $result["soapBody"]["ns1OTA_AirAvailRS"]["ns1OriginDestinationInformation"];
            if (!isset($flightsResult[0])) {
                function hoursandmins($time, $format = '%02d:%02d')
                {
                    if ($time < 1) {
                        return;
                    }
                    $hours = floor($time / 60);
                    $minutes = ($time % 60);
                    return sprintf($format, $hours, $minutes);
                }
                // print_r($flightsResult);
                // echo $flightsResult["ns1DepartureDateTime"] . "fsfsdf";
                $dptTime = date("H:i", strtotime($flightsResult["ns1DepartureDateTime"]));
                $arvlTime = date("H:i", strtotime($flightsResult["ns1ArrivalDateTime"]));
                $trvlTime = ((strtotime($flightsResult["ns1DepartureDateTime"]) - strtotime($flightsResult["ns1ArrivalDateTime"])));
                $timeGap = hoursandmins($trvlTime);
                $originLoc = $flightsResult["ns1OriginLocation"];
                $destiLoc = $flightsResult["ns1DestinationLocation"];
                $flightNumber = $flightsResult["ns1OriginDestinationOptions"]["ns1OriginDestinationOption"]["ns1FlightSegment"]["@attributes"]["FlightNumber"];
            ?>
                <div class="col-md-6">
                    <div class="shownd_flights">
                        <div class="flight_detail_shownd_flight">
                            <div class="desti_time">
                                <h2><?= $arvlTime ?></h2>
                                <p><?= $_GET["flying_from_N"] ?></p>
                            </div>

                            <div class="desti_time_stop">
                                <h2><?= $timeGap ?><span>Non-Stop</span></h2>
                                <p><?= $_GET["flying_from_N"] ?> -> <?= $_GET["flying_to_N"] ?></p>
                            </div>

                            <div class="desti_time">
                                <h2><?= $dptTime ?></h2>
                                <p><?= $_GET["flying_to_N"] ?></p>
                            </div>

                            <!-- <div class="flight_company_logo">
                                <img src="img/flight_logo.svg" />
                                <p>AirIndia<span>AI-883</span></p>
                            </div> -->

                            <!-- <div class="seat_flight_detail">
                                <span>
                                    <p><i class="fas fa-user"></i> 2 Seats Left</p>
                                </span>
                                <a href="#"><i class="fas fa-plane-departure"></i> Flight Details</a>
                            </div> -->

                        </div>

                        <div class="price_book_shownd_flight">
                            <h2>₹5,608</h2>
                            <a href="book_flight.html">Book</a>
                        </div>
                    </div>
                </div>
                <?php
            } else {
                $a = 0;
                foreach ($flightsResult as $flights) {
                    $dptTime = $flights["ns1DepartureDateTime"];
                    $arvlTime = $flights["ns1ArrivalDateTime"];
                    $originLoc = $flights["ns1OriginLocation"];
                    $destiLoc = $flights["ns1DestinationLocation"];
                    $flightNumber = $flights["ns1OriginDestinationOptions"]["ns1OriginDestinationOption"]["ns1FlightSegment"]["@attributes"]["FlightNumber"];
                ?>
                    <div class="col-md-6">
                        <div class="shownd_flights">
                            <div class="flight_detail_shownd_flight">
                                <div class="desti_time">
                                    <h2><?= $arvlTime ?></h2>
                                    <p><?= $originLoc ?></p>
                                </div>

                                <div class="desti_time_stop">
                                    <h2>2h 5m <span>Non-Stop</span></h2>
                                    <p><?= $_GET["flying_from_N"] ?> -> <?= $_GET["flying_to_N"] ?></p>
                                </div>

                                <div class="desti_time">
                                    <h2>13:10</h2>
                                    <p>Delhi</p>
                                </div>

                                <div class="flight_company_logo">
                                    <img src="img/flight_logo.svg" />
                                    <p>AirIndia<span>AI-883</span></p>
                                </div>

                                <div class="seat_flight_detail">
                                    <span>
                                        <p><i class="fas fa-user"></i> 2 Seats Left</p>
                                    </span>
                                    <a href="#"><i class="fas fa-plane-departure"></i> Flight Details</a>
                                </div>

                            </div>

                            <div class="price_book_shownd_flight">
                                <h2>₹5,608</h2>
                                <a href="book_flight.html">Book</a>
                            </div>
                        </div>
                    </div>
            <?php
                }
                $a++;
            }
            ?>

            <!-- <div class="col-md-6">
                <div class="shownd_flights">
                    <div class="flight_detail_shownd_flight">
                        <div class="desti_time">
                            <h2>13:10</h2>
                            <p>Delhi</p>
                        </div>

                        <div class="desti_time_stop">
                            <h2>2h 5m <span>Non-Stop</span></h2>
                            <p>DEL -> GOI</p>
                        </div>

                        <div class="desti_time">
                            <h2>13:10</h2>
                            <p>Delhi</p>
                        </div>

                        <div class="flight_company_logo">
                            <img src="img/flight_logo.svg" />
                            <p>AirIndia<span>AI-883</span></p>
                        </div>

                        <div class="seat_flight_detail">
                            <span>
                                <p><i class="fas fa-user"></i> 2 Seats Left</p>
                            </span>
                            <a href="#"><i class="fas fa-plane-departure"></i> Flight Details</a>
                        </div>

                    </div>

                    <div class="price_book_shownd_flight">
                        <h2>₹5,608</h2>
                        <a href="book_flight.html">Book</a>
                    </div>
                </div>
            </div> -->
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skiez\resources\views/flight-search.blade.php ENDPATH**/ ?>