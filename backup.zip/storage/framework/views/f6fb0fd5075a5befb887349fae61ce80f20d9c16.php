<!doctype html>
<html>

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="icon" href="<?php echo e(env('ASSETS_URL')); ?>img/favicon.png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(env('ASSETS_URL')); ?>css/bootstrap.min.css">
    <!-- animate CSS -->
    <link rel="stylesheet" href="<?php echo e(env('ASSETS_URL')); ?>css/animate.css">
    <!-- owl carousel CSS -->
    <link rel="stylesheet" href="<?php echo e(env('ASSETS_URL')); ?>css/owl.carousel.min.css">
    <!-- themify CSS -->
    <link rel="stylesheet" href="<?php echo e(env('ASSETS_URL')); ?>css/themify-icons.css">
    <!-- flaticon CSS -->
    <link rel="stylesheet" href="<?php echo e(env('ASSETS_URL')); ?>css/flaticon.css">
    <!-- fontawesome CSS -->
    <link rel="stylesheet" href="<?php echo e(env('ASSETS_URL')); ?>fontawesome/css/all.min.css">
    <!-- magnific CSS -->
    <link rel="stylesheet" href="<?php echo e(env('ASSETS_URL')); ?>css/magnific-popup.css">
    <link rel="stylesheet" href="<?php echo e(env('ASSETS_URL')); ?>css/gijgo.min.css">
    <!-- niceselect CSS -->
    <link rel="stylesheet" href="<?php echo e(env('ASSETS_URL')); ?>css/nice-select.css">
    <!-- slick CSS -->
    <link rel="stylesheet" href="<?php echo e(env('ASSETS_URL')); ?>css/slick.css">
    <!-- style CSS -->
    <link rel="stylesheet" href="<?php echo e(env('ASSETS_URL')); ?>css/style.css">



    <link href="<?php echo e(env('ASSETS_URL')); ?>bundles/css19a0.css?v=1234455667899" rel="stylesheet" />
    <script src="<?php echo e(env('ASSETS_URL')); ?>bundles/Script9776?v=gthh"></script>


    <!-- font awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">


    <!------------------------------ google fonts ------------------------------>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">


    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">

    <style>
        /* Extra styles for the cancel button */
        .cancelbtn {
            width: auto;
            padding: 10px 18px;
            background-color: #2493e0;
        }

        /* Center the image and position the close button */
        .imgcontainer {
            text-align: center;
            margin: 24px 0 12px 0;
            position: relative;
        }

        img.avatar {
            width: 40%;
            border-radius: 50%;
        }

        span.psw {
            float: right;
            padding-top: 16px;
        }

        /* The Modal (background) */
        .modal {
            display: none;
            /* Hidden by default */
            position: fixed;
            /* Stay in place */
            z-index: 99999;
            /* Sit on top */
            left: 0;
            top: 0;
            width: 100%;
            /* Full width */
            height: 100%;
            /* Full height */
            overflow: auto;
            /* Enable scroll if needed */
            background-color: rgb(0, 0, 0);
            /* Fallback color */
            background-color: rgba(0, 0, 0, 0.4);
            /* Black w/ opacity */
            padding-top: 60px;
        }

        .modall {
            display: none;
            /* Hidden by default */
            position: fixed;
            /* Stay in place */
            z-index: 99999;
            /* Sit on top */
            left: 0;
            top: 0;
            width: 100%;
            /* Full width */
            height: 100%;
            /* Full height */
            overflow: auto;
            /* Enable scroll if needed */
            background-color: rgb(0, 0, 0);
            /* Fallback color */
            background-color: rgba(0, 0, 0, 0.4);
            /* Black w/ opacity */
            padding-top: 60px;
        }

        /* Modal Content/Box */
        .modal-content {
            flex-direction: inherit !important;
            background-color: #fefefe;
            margin: 5% auto 0% auto;
            border: 1px solid #888;
            width: 35%;
            padding: 30px 50px 30px 50px;
            border-radius: 13px;
            border: none;
            text-align: center;
        }

        /* The Close Button (x) */
        .close {
            position: absolute;
            right: 13px;
            top: 0;
            color: #000;
            font-size: 30px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #2493e0;
            cursor: pointer;
        }

        /* Add Zoom Animation */
        .animate {
            -webkit-animation: animatezoom 0.6s;
            animation: animatezoom 0.6s
        }

        .animateee {
            width: 100%;
            float: left;
        }

        .animateee h6 {
            font-size: 17px;
            text-align: center;
            font-weight: 400;
            color: #000000c4;
            margin-bottom: 25px;
            margin-top: 30px;
            font-family: 'Poppins', sans-serif;
        }

        .animateee h6 span {
            font-weight: 600;
        }



        .animateee input {
            margin-bottom: 10px;
            padding: 10px 10px 10px 12px;
            width: 90%;
            float: left;
            border: none;
            border-radius: 0px;
            font-size: 15px;
            background: #F7F7F7;
            border-left: 5px solid #08423b;
        }

        .pop_span2 {
            width: 10%;
            float: left;
            background: #F7F7F7;
            padding: 10px 0;
        }

        .pop_span2 i {
            color: #00000042;
        }

        .animateee button {
            border: 0;
            width: 100%;
            float: left;
            margin-top: 15px;
            padding: 10px 0;
        }

        .animateee input::placeholder {
            color: #00000042;
        }

        .agent_btm_pop {
            width: 100%;
            float: left;
            border-top: 1px solid #00000017;
            margin-top: 40px;
            padding-top: 12px;
        }

        .agent_btm_pop p {
            margin: 0;
            width: 50%;
            float: left;
            text-align: right;
            font-size: 12px;
            color: #08413b;
            font-weight: 500;
            font-family: 'Poppins', sans-serif;
            padding-right: 5px;
            padding-top: 5px;
        }

        .agent_btm_pop button {
            width: auto;
            float: inherit;
            font-size: 12px;
            margin-top: 0;
            padding: 9px 14px;
            background: #08413b;
            margin-left: 10px;
        }

        .or_sec {
            border-top: 1px solid #bdbbbb54;
            margin-top: 35px;
        }

        .or_sec h5 {
            width: 12%;
            background: #fff;
            margin-top: -13px !important;
            margin: 0 auto;
        }

        .or_sec a {
            width: 50%;
            float: left;
            margin-top: 20px;
            text-align: center;
        }

        .or_sec a img {
            width: 85%;
        }

        @-webkit-keyframes animatezoom {
            from {
                -webkit-transform: scale(0)
            }

            to {
                -webkit-transform: scale(1)
            }
        }

        @keyframes  animatezoom {
            from {
                transform: scale(0)
            }

            to {
                transform: scale(1)
            }
        }

        /* Change styles for span and cancel button on extra small screens */
        @media  screen and (max-width: 300px) {
            span.psw {
                display: block;
                float: none;
            }

            .cancelbtn {
                width: 100%;
            }
        }
    </style>
</head>

<body>
    <!-------------------------------------::login/register modal::--------------------------------------->
    <div id="id01" class="modal">
        <div class="modal-content">
            <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
            <form class="animate animateee">
                <img src="<?php echo e(env('ASSETS_URL')); ?>img/logo.svg" />
                <h6>Nice to see you again.. <span>Login here</span></h6>
                <div class="container">
                    <input type="text" placeholder="Your 10 digit mobile number" name="uname">
                    <span class="pop_span2">
                        <i class="fas fa-mobile-alt"></i>
                    </span><br>

                    <button type="button" class="btn_1 d-none d-lg-block" onclick="location.href='user_dashboard.html'">GENERATE OTP</button>


                    <div class="agent_btm_pop">
                        <p>Are you aS kiez Agent</p>
                        <button type="button" class="btn_1 d-none d-lg-block" data-toggle="modal" data-target="#exampleModal">Agent Login</button>
                    </div>

                </div>


            </form>
        </div>
    </div>



    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content w-100 mt-5">

                <form class="animate animateee">
                    <img src="<?php echo e(env('ASSETS_URL')); ?>img/logo.svg" />
                    <h6>Nice to see you again.. <span>Login here</span></h6>
                    <div class="container">
                        <input type="text" placeholder="Your 10 digit mobile number" name="uname">
                        <span class="pop_span2">
                            <i class="fas fa-mobile-alt"></i>
                        </span><br>

                        <button type="button" class="btn_1 d-none d-lg-block" onclick="location.href='agent_dashboard.html'">GENERATE OTP</button>


                    </div>


                </form>
            </div>
        </div>
    </div>

    <!--::header part start::-->
    <header class="main_menu">
        <div class="sub_menu">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-2">
                        <div class="sub_menu_social_icon" style="float: left;">
                            <span><img src="<?php echo e(env('ASSETS_URL')); ?>img/phone_top_icon.svg" class="mr-2" />+000 000 000 000</a></span>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-2 ">
                        <div class="sub_menu_social_icon">
                            <a href="#"><img src="<?php echo e(env('ASSETS_URL')); ?>img/facebook.svg" /></a>
                            <a href="#"><img src="<?php echo e(env('ASSETS_URL')); ?>img/insta.svg" /></a>
                            <a href="#"><img src="<?php echo e(env('ASSETS_URL')); ?>img/twitter.svg" /></a>
                            <a href="#"><img src="<?php echo e(env('ASSETS_URL')); ?>img/linkdin.svg" /></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="main_menu_iner">
            <div class="container">
                <div class="row align-items-center ">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg navbar-light justify-content-between">
                            <a class="navbar-brand" href="<?php echo e(route('home')); ?>"> <img src="<?php echo e(env('ASSETS_URL')); ?>img/logo.svg" alt="logo" style="width: 90%;" /> </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse main-menu-item" id="navbarSupportedContent">
                                <ul class="navbar-nav">
                                    <li class="nav-item">
                                        <a class="nav-link <?php echo e(route('home') == Request::url() ? 'active_nav' : ''); ?>" href="<?php echo e(route('home')); ?>">Home</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link <?php echo e(route('about') == Request::url() ? 'active_nav' : ''); ?>" href="<?php echo e(route('about')); ?>">About</a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link <?php echo e(route('flightBooking') == Request::url() ? 'active_nav' : ''); ?>" href="<?php echo e(route('flightBooking')); ?>">Flight Booking</a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link <?php echo e(route('hotelBooking') == Request::url() ? 'active_nav' : ''); ?>" href="<?php echo e(route('hotelBooking')); ?>">Hotel Booking</a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link <?php echo e(route('packages') == Request::url() ? 'active_nav' : ''); ?>" href="<?php echo e(route('packages')); ?>">packages</a>
                                    </li>
                                </ul>
                            </div>
                            <a href="#" class="btn_1 d-lg-block d-none main_login" onclick="document.getElementById('id01').style.display='block'">Log In</a>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header part end-->

    <?php echo $__env->yieldContent('content'); ?>

    <!-- footer part start-->
    <footer class="footer-area">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-sm-6 col-md-2">
                    <div class="single-footer-widget">
                        <h4>Quick Links</h4>
                        <ul>
                            <li><a href="#">Home</a></li>
                            <li><a href="#">About Company</a></li>
                            <li><a href="#">Testimonials</a></li>
                            <li><a href="#">Infrastructure</a></li>
                        </ul>

                    </div>
                </div>


                <div class="col-sm-6 col-md-2">
                    <div class="single-footer-widget">
                        <h4>Support</h4>
                        <ul>
                            <li><a href="#">Get Started</a></li>
                            <li><a href="#">Lorem</a></li>
                            <li><a href="#">Help</a></li>
                            <li><a href="#">Ipsum</a></li>
                        </ul>

                    </div>
                </div>


                <div class="col-sm-6 col-md-3">
                    <div class="single-footer-widget footer_icon">
                        <h4>Address</h4>
                        <p>14, 1 Ellis bridge ST,
                            auckland 3500, Australia<br>

                            +1234567890<br>
                            contactus@demo.com
                        </p>


                    </div>
                </div>

                <div class="col-sm-6 col-md-1"></div>


                <div class="col-sm-6 col-md-3">
                    <div class="single-footer-widget">
                        <h4>Subscribe Newsletter</h4>
                        <div class="form-wrap" id="mc_embed_signup">
                            <form target="_blank" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get" class="form-inline">
                                <input class="form-control" name="EMAIL" placeholder="Your Email Address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Email Address '" required="" type="email">
                                <button class="click-btn btn btn-default text-uppercase"> <i class="far fa-paper-plane"></i>
                                </button>
                                <div style="position: absolute; left: -5000px;">
                                    <input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value="" type="text">
                                </div>

                                <div class="info"></div>
                            </form>
                        </div>
                        <p>Download Our App</p>

                        <div class="dwnloade_icons">
                            <a href="#"><img src="<?php echo e(env('ASSETS_URL')); ?>img/play_store.svg" /></a>
                            <a href="#"><img src="<?php echo e(env('ASSETS_URL')); ?>img/google-play.svg" /></a>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="copyright_part_text text-center">
                        <p class="footer-text m-0">
                            &copy; 2020 Reserved by ABC Company Limited.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer part end-->

    <!-- jquery plugins here-->
    <script src="<?php echo e(env('ASSETS_URL')); ?>js/jquery-1.12.1.min.js"></script>
    <!-- popper js -->
    <script src="<?php echo e(env('ASSETS_URL')); ?>js/popper.min.js"></script>
    <!-- bootstrap js -->
    <script src="<?php echo e(env('ASSETS_URL')); ?>js/bootstrap.min.js"></script>
    <!-- magnific js -->
    <script src="<?php echo e(env('ASSETS_URL')); ?>js/jquery.magnific-popup.js"></script>
    <!-- swiper js -->
    <script src="<?php echo e(env('ASSETS_URL')); ?>js/owl.carousel.min.js"></script>
    <!-- masonry js -->
    <script src="<?php echo e(env('ASSETS_URL')); ?>js/masonry.pkgd.js"></script>
    <!-- masonry js -->
    <script src="<?php echo e(env('ASSETS_URL')); ?>js/jquery.nice-select.min.js"></script>
    <script src="<?php echo e(env('ASSETS_URL')); ?>js/gijgo.min.js"></script>
    <!-- contact js -->
    <script src="<?php echo e(env('ASSETS_URL')); ?>js/jquery.ajaxchimp.min.js"></script>
    <script src="<?php echo e(env('ASSETS_URL')); ?>js/jquery.form.js"></script>
    <script src="<?php echo e(env('ASSETS_URL')); ?>js/jquery.validate.min.js"></script>
    <script src="<?php echo e(env('ASSETS_URL')); ?>js/mail-script.js"></script>
    <script src="<?php echo e(env('ASSETS_URL')); ?>js/contact.js"></script>
    <!-- custom js -->
    <script src="<?php echo e(env('ASSETS_URL')); ?>js/custom.js"></script>



    <!-- Login Modal -->
    <script>
        // Get the modal
        var modal = document.getElementById('id01');

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

        function next() {
            window.location.assign("flight_search.html")
        }
    </script>







</body>



</html><?php /**PATH C:\xampp\htdocs\skiez\resources\views/layouts/master.blade.php ENDPATH**/ ?>