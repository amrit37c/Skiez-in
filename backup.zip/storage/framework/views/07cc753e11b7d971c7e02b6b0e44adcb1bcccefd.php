<!-- Stored in resources/views/child.blade.php -->


<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##

    <p>This is appended to the master sidebar.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <!-------------------------------------::login/register modal::--------------------------------------->
        <div id="id01" class="modal">
        <div class="modal-content">
            <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
            <form class="animate animateee">
                <img src="<?php echo e(env('ASSETS_URL')); ?>img/logo.svg" />
                <h6>Nice to see you again.. <span>Login here</span></h6>
                <div class="container">
                    <input type="text" placeholder="Your 10 digit mobile number" name="uname">
                    <span class="pop_span2">
                        <i class="fas fa-mobile-alt"></i>
                    </span><br>

                    <button type="button" class="btn_1 d-none d-lg-block" onclick="location.href='user_dashboard.html'">GENERATE OTP</button>


                    <div class="agent_btm_pop">
                        <p>Are you aS kiez Agent</p>
                        <button type="button" class="btn_1 d-none d-lg-block" data-toggle="modal" data-target="#exampleModal">Agent Login</button>
                    </div>

                </div>


            </form>
        </div>
    </div>



    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content w-100 mt-5">

                <form class="animate animateee">
                    <img src="<?php echo e(env('ASSETS_URL')); ?>img/logo.svg" />
                    <h6>Nice to see you again.. <span>Login here</span></h6>
                    <div class="container">
                        <input type="text" placeholder="Your 10 digit mobile number" name="uname">
                        <span class="pop_span2">
                            <i class="fas fa-mobile-alt"></i>
                        </span><br>

                        <button type="button" class="btn_1 d-none d-lg-block" onclick="location.href='agent_dashboard.html'">GENERATE OTP</button>


                    </div>


                </form>
            </div>
        </div>
    </div>

    <!--::header part start::-->
    <header class="main_menu">
        <div class="sub_menu">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-2">
                        <div class="sub_menu_social_icon" style="float: left;">
                            <span><img src="<?php echo e(env('ASSETS_URL')); ?>img/phone_top_icon.svg" class="mr-2" />+000 000 000 000</a></span>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-2 ">
                        <div class="sub_menu_social_icon">
                            <a href="#"><img src="<?php echo e(env('ASSETS_URL')); ?>img/facebook.svg" /></a>
                            <a href="#"><img src="<?php echo e(env('ASSETS_URL')); ?>img/insta.svg" /></a>
                            <a href="#"><img src="<?php echo e(env('ASSETS_URL')); ?>img/twitter.svg" /></a>
                            <a href="#"><img src="<?php echo e(env('ASSETS_URL')); ?>img/linkdin.svg" /></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="main_menu_iner">
            <div class="container">
                <div class="row align-items-center ">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg navbar-light justify-content-between">
                            <a class="navbar-brand" href="index.html"> <img src="<?php echo e(env('ASSETS_URL')); ?>img/logo.svg" alt="logo" style="width: 90%;" /> </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse main-menu-item" id="navbarSupportedContent">
                                <ul class="navbar-nav">
                                    <li class="nav-item">
                                        <a class="nav-link active_nav" href="index.html">Home</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="about.html">About</a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link" href="flight_booking.html">Flight Booking</a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link" href="hotel_booking.html">Hotel Booking</a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link" href="packages.html">packages</a>
                                    </li>
                                </ul>
                            </div>
                            <a href="#" class="btn_1 d-lg-block d-none main_login" onclick="document.getElementById('id01').style.display='block'">Log In</a>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header part end-->

    <!-- banner part start-->
    <section class="banner_part">
        <div class="container">
            <div class="row align-items-center justify-content-center">
                <div class="col-lg-10">
                    <div class="banner_text text-center">
                        <div class="banner_text_iner">
                            <h1>DISCOVER WITH US</h1>
                            <p>Let’s start your journey with us, your dream will come true</p>
                            <a href="#" class="btn_1">Discover Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- banner part start-->


    <!-- booking part start-->
    <section class="booking_part">
        <div class="container book_check_sec">
            <div class="row">
                <div class="col-lg-12">
                    <div class="booking_menu">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="hotel-tab" data-toggle="tab" href="#flight" role="tab" aria-controls="hotel" aria-selected="true"><img src="<?php echo e(env('ASSETS_URL')); ?>img/flight_icon.svg" class="book_tab_icon" /> Flight</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" id="place-tab" data-toggle="tab" href="#hotel" role="tab" aria-controls="place" aria-selected="false"><img src="<?php echo e(env('ASSETS_URL')); ?>img/hotel_icon.svg" class="book_tab_icon" /> Hotel</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" id="tricket-tab" data-toggle="tab" href="#hotel_flight" role="tab" aria-controls="tricket" aria-selected="false"><img src="<?php echo e(env('ASSETS_URL')); ?>img/hotel_icon.svg" class="book_tab_icon" /> Flight + Hotel</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" id="tricket-tab" data-toggle="tab" href="#" role="tab" aria-controls="tricke" aria-selected="false"><img src="<?php echo e(env('ASSETS_URL')); ?>img/car_icon.svg" class="book_tab_icon" /> Flight + Car</a>
                            </li>

                        </ul>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="booking_content" style="height: 245px;">
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="flight" role="tabpanel" aria-labelledby="hotel-tab">
                                <div class="booking_form">
                                    <script src="<?php echo e(env('ASSETS_URL')); ?>bundles/seachengine02b9?v=4242424242424"></script>

                                    <form action="" method="post">
                                        <input id="from_wait" value="" type="hidden" />
                                        <input id="to_wait" value="" type="hidden" />
                                        <input type="hidden" name="device_app" id="device_app" value="2" />
                                        <input type="hidden" name="hfFromDate" id="hfFromDate" value="04/12/2020" />
                                        <input type="hidden" name="hfToDate" id="hfToDate" value="" />
                                        <input type="hidden" name="hfTripType" id="hfTripType" value="false" />
                                        <input type="hidden" name="hfAdult" id="hfAdult" value="" />
                                        <input type="hidden" name="hfChild" id="hfChild" value='' />
                                        <input type="hidden" name="hfInfant" id="hfInfant" value='' />
                                        <input type="hidden" name="hfdirect" id="hfdirect" />
                                        <input type="hidden" name="hdn_flying_from" id="hdn_flying_from" value="" />
                                        <input type="hidden" name="hdn_flying_to" id="hdn_flying_to" value="" />
                                        <input type="hidden" name="modify" id="modify" value="1" />

                                        <section class="serchBox">


                                            <div class="searchEng">
                                                <div class="waybtn">
                                                    <button onclick="return SelectTripType('O')" class="slt oneway">One way</button>
                                                    <button class="roundway" onclick="return SelectTripType('R')">Round trip</button>
                                                </div>



                                                <div class="srcformbx">

                                                    <div class="col-6 col-lg-3 lbl swap">
                                                        <strong class="swap">From </strong>
                                                        <input type="text" name="flying_from_N" value="" class="fly-from-input" placeholder="From" id="flying_from_N" onclick="autodiv_from();" autocomplete="off" />
                                                        <b id="Fly_Depart_airport">Airport Name or City Name</b>
                                                        <img src="<?php echo e(env('ASSETS_URL')); ?>img/swap.png" style="cursor:pointer;" onclick="swapfun()" width="31" height="30" alt="Swap" title="Swap">
                                                        <div class="fromtopopup frompopup">
                                                            <label>
                                                                <i class="fa fa-search"></i>
                                                                <input type="text" name="flying_from" class="fly-from-input ac_input" autocomplete="off" placeholder="From" id="flying_from" />
                                                            </label>
                                                            <div class="staticway">
                                                                <h5>Popular Cities</h5>
                                                                <ul>
                                                                    <li onclick="setsearhengine('Delhi', 'DEL', 'Indira Gandhi International Airport', 'India', 'IN')">
                                                                        Delhi</li>
                                                                    <li onclick="setsearhengine('Bangalore', 'BLR', 'Bengaluru International Airport', 'India', 'IN')">
                                                                        Bangalore</li>
                                                                    <li onclick="setsearhengine('Mumbai', 'BOM', 'Chhatrapati Shivaji International Airport', 'India', 'IN')">
                                                                        Mumbai</li>
                                                                    <li onclick="setsearhengine('Hyderabad', 'HYD', 'Shamshabad Rajiv Gandhi International Airport', 'India', 'IN')">
                                                                        Hyderabad</li>
                                                                    <li onclick="setsearhengine('Kolkata', 'CCU', 'Netaji Subhas Chandra Bose International Airport', 'India', 'IN')">
                                                                        Kolkata</li>
                                                                    <li onclick="setsearhengine('Chennai', 'MAA', 'Chennai Airport', 'India', 'IN')">
                                                                        Chennai/Madras</li>
                                                                    <li onclick="setsearhengine('Ahmedabad', 'AMD', 'Ahmedabad International Airport', 'India', 'IN')">
                                                                        Ahmedabad</li>
                                                                    <li onclick="setsearhengine('Pune', 'PNQ', 'Lohegaon Airport', 'India', 'IN')">
                                                                        Pune</li>
                                                                    <li onclick="setsearhengine('Guwahati', 'GAU', 'Bordoloi International Airport', 'India', 'IN')">
                                                                        Guwahati</li>
                                                                    <li onclick="setsearhengine('Goa', 'GOI', 'Dabolim Airport', 'India', 'IN')">
                                                                        Goa</li>
                                                                    <li onclick="setsearhengine('Lucknow', 'LKO', 'Amausi Airport', 'India', 'IN')">
                                                                        Lucknow</li>
                                                                    <li onclick="setsearhengine('Bhubaneswar', 'BBI', 'Biju Patnaik Airport', 'India', 'IN')">
                                                                        Bhubaneswar</li>
                                                                    <li onclick="setsearhengine('Cochin', 'COK', 'Chochin International Airport', 'India', 'IN')">
                                                                        Cochin</li>
                                                                    <li onclick="setsearhengine('Jaipur', 'JAI', 'Sanganeer Airport', 'India', 'IN')">
                                                                        Jaipur</li>
                                                                    <li onclick="setsearhengine('Patna', 'PAT', 'Jai Prakash Narayan Airport', 'India', 'IN')">
                                                                        Patna</li>
                                                                    <li onclick="setsearhengine('Srinagar', 'SXR', 'Srinagar International Airport', 'India', 'IN')">
                                                                        Srinagar</li>
                                                                    <li onclick="setsearhengine('Nagpur', 'NAG', 'Dr Ambedkar International Airport', 'India', 'IN')">
                                                                        Nagpur</li>
                                                                    <li onclick="setsearhengine('Agartala', 'IXA', 'Singerbhil Airport', 'India', 'IN')">
                                                                        Agartala</li>
                                                                </ul>
                                                            </div>

                                                        </div>
                                                    </div>

                                                    <div class="col-6 col-lg-3 lbl">

                                                        <strong>To</strong>
                                                        <input name="flying_to_N" type="text" class="fly-to-input" value="" placeholder="To" id="flying_to_N" onclick="autodiv_to();" autocomplete="off" />
                                                        <b id="Fly_Dest_airport">Airport Name or City Name</b>

                                                        <div class="fromtopopup topopup">
                                                            <label>
                                                                <i class="fa fa-search"></i>

                                                                <input type="text" name="flying_to" class="fly-from-input ac_input" autocomplete="off" placeholder="To" id="flying_to" />
                                                            </label>
                                                            <div class="staticway">
                                                                <h5>Popular Cities</h5>
                                                                <ul>
                                                                    <li onclick="setsearhengine_Return('Delhi', 'DEL', 'Indira Gandhi International Airport', 'India', 'IN')">
                                                                        Delhi</li>
                                                                    <li onclick="setsearhengine_Return('Bangalore', 'BLR', 'Bengaluru International Airport', 'India', 'IN')">
                                                                        Bangalore</li>
                                                                    <li onclick="setsearhengine_Return('Mumbai', 'BOM', 'Chhatrapati Shivaji International Airport', 'India', 'IN')">
                                                                        Mumbai</li>
                                                                    <li onclick="setsearhengine_Return('Hyderabad', 'HYD', 'Shamshabad Rajiv Gandhi International Airport', 'India', 'IN')">
                                                                        Hyderabad</li>
                                                                    <li onclick="setsearhengine_Return('Kolkata', 'CCU', 'Netaji Subhas Chandra Bose International Airport', 'India', 'IN')">
                                                                        Kolkata</li>
                                                                    <li onclick="setsearhengine_Return('Chennai', 'MAA', 'Chennai Airport', 'India', 'IN')">
                                                                        Chennai/Madras</li>
                                                                    <li onclick="setsearhengine_Return('Ahmedabad', 'AMD', 'Ahmedabad International Airport', 'India', 'IN')">
                                                                        Ahmedabad</li>
                                                                    <li onclick="setsearhengine_Return('Pune', 'PNQ', 'Lohegaon Airport', 'India', 'IN')">
                                                                        Pune</li>
                                                                    <li onclick="setsearhengine_Return('Guwahati', 'GAU', 'Bordoloi International Airport', 'India', 'IN')">
                                                                        Guwahati</li>
                                                                    <li onclick="setsearhengine_Return('Goa', 'GOI', 'Dabolim Airport', 'India', 'IN')">
                                                                        Goa</li>
                                                                    <li onclick="setsearhengine_Return('Lucknow', 'LKO', 'Amausi Airport', 'India', 'IN')">
                                                                        Lucknow</li>
                                                                    <li onclick="setsearhengine_Return('Bhubaneswar', 'BBI', 'Biju Patnaik Airport', 'India', 'IN')">
                                                                        Bhubaneswar</li>
                                                                    <li onclick="setsearhengine_Return('Cochin', 'COK', 'Chochin International Airport', 'India', 'IN')">
                                                                        Cochin</li>
                                                                    <li onclick="setsearhengine_Return('Jaipur', 'JAI', 'Sanganeer Airport', 'India', 'IN')">
                                                                        Jaipur</li>
                                                                    <li onclick="setsearhengine_Return('Patna', 'PAT', 'Jai Prakash Narayan Airport', 'India', 'IN')">
                                                                        Patna</li>
                                                                    <li onclick="setsearhengine_Return('Srinagar', 'SXR', 'Srinagar International Airport', 'India', 'IN')">
                                                                        Srinagar</li>
                                                                    <li onclick="setsearhengine_Return('Nagpur', 'NAG', 'Dr Ambedkar International Airport', 'India', 'IN')">
                                                                        Nagpur</li>
                                                                    <li onclick="setsearhengine_Return('Agartala', 'IXA', 'Singerbhil Airport', 'India', 'IN')">
                                                                        Agartala</li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-6 col-lg-2 lbl" id="Fly_dep_datepickerid">
                                                        <strong>Departure <i class="fa fa-angle-down"></i></strong>
                                                        <input id="datepicker_1" placeholder="00/00/0000" style="font-size: 20px;margin-top: 19px;">
                                                    </div>
                                                    <div class="col-6 col-lg-2 lbl" onclick="return SelectTripType('R')" id="Fly_ret_datepickerid" disabled="disabled" style="cursor: no-drop; background: #f5f2f2; ">
                                                        <strong>Return <i class="fa fa-angle-down"></i></strong>
                                                        <input id="datepicker_2" placeholder="00/00/0000" style="font-size: 20px;margin-top: 19px;">
                                                    </div>
                                                    <div class="col-12 col-lg-2 lbl lst" id="adult_div">
                                                        <input type="hidden" id="adult" name="adult" value="1" />
                                                        <strong>Travellers & Class <i class="fa fa-angle-down"></i></strong>
                                                        <span><big id="travel_id">1</big> Traveller</span>
                                                        <b id="cabin_id">Economy</b>

                                                    </div>

                                                    <div class="popup adultdrop">
                                                        <span class="adult1">
                                                            <span class="ad_left">
                                                                <img src="<?php echo e(env('ASSETS_URL')); ?>img/adult.png" alt="Adult Flights">
                                                                Adults (12+)
                                                            </span> <span class="ad_right">
                                                                <input type="button" class="minus maincalulation" value="-" id="sub1minus">
                                                                <input type="text" class="count" value="1" id="sub1">
                                                                <input type="button" class="plus maincalulation" value="+" id="sub1plus">
                                                            </span>
                                                        </span>
                                                        <span class="adult1">
                                                            <span class="ad_left">
                                                                <img src="<?php echo e(env('ASSETS_URL')); ?>img/child.png" alt="Child Flights">
                                                                Children (2-11)
                                                            </span>
                                                            <span class="ad_right">
                                                                <input type="button" class="minus maincalulation" value="-" id="sub2minus">
                                                                <input type="text" class="count" value="0" id="sub2">
                                                                <input type="button" class="plus maincalulation" value="+" id="sub2plus">
                                                            </span>
                                                        </span>
                                                        <span class="adult1">
                                                            <span class="ad_left">
                                                                <img src="<?php echo e(env('ASSETS_URL')); ?>img/infant.png" alt="Infant Flights">
                                                                Infant
                                                            </span>
                                                            <span class="ad_right">
                                                                <input type="button" class="minus maincalulation" value="-" id="sub3minus">
                                                                <input type="text" class="count" value="0" id="sub3">
                                                                <input type="button" class="plus maincalulation" value="+" id="sub3plus">
                                                            </span>
                                                        </span>
                                                        <div>
                                                            <span>&nbsp;</span>
                                                            <span>Choose Travel Class</span>
                                                        </div>
                                                        <div class="search-sixbox">
                                                            <select name="ddlCabinClass" id="ddlCabinClass" onchange="getval_Cabin();" class=" fly-cabin-input ac_input">
                                                                <option value="2" selected="selected">Economy</option>
                                                                <option value="3">Premium Economy</option>
                                                                <option value="4">Business</option>
                                                                <option value="6">First</option>
                                                            </select>

                                                            <div class="search-eightbox" style="display:none;">
                                                                <div class="custom-control custom-checkbox pt-2 text-left">
                                                                    <input type="checkbox" id="chkIsDirect" class="custom-control-input">
                                                                    <label class="custom-control-label" for="chkIsDirect">Direct
                                                                        Flight</label>
                                                                </div>
                                                            </div>

                                                        </div>
                                                        <span class="done"><a>Done</a></span>

                                                    </div>

                                                </div>
                                            </div>

                                        </section>
                                        <style>
                                            .fromtopopup {
                                                display: none;
                                                width: 340px;
                                                position: absolute;
                                                left: 0;
                                                top: 30px;
                                                float: left;
                                                -webkit-border-radius: 4px;
                                                -moz-border-radius: 4px;
                                                border-radius: 4px;
                                                background-color: #ffffff;
                                                -webkit-box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.2);
                                                -moz-box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.2);
                                                box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.2);
                                                z-index: 9999;
                                            }

                                            .fromtopopup label {
                                                width: 100%;
                                                position: relative;
                                                min-height: auto;
                                            }

                                            .fromtopopup label i {
                                                position: absolute;
                                                left: 10px;
                                                top: 15px;
                                                font-size: 12px;
                                            }

                                            .fromtopopup p {
                                                color: #666;
                                                font-size: 13px;
                                                padding: 0px 10px;
                                            }

                                            .fromtopopup input {
                                                width: 100% !important;
                                                background: #ffffff !important;
                                                -webkit-box-shadow: 0 2px 3px 0 rgba(204, 204, 204, 0.1);
                                                -moz-box-shadow: 0 2px 3px 0 rgba(204, 204, 204, 0.1);
                                                box-shadow: 0 2px 3px 0 rgba(204, 204, 204, 0.1);
                                                padding: 11px 10px 11px 30px;
                                                outline: 0;
                                                border: 0;
                                                width: 100%;
                                                font-size: 15px !important;
                                                color: #666;
                                                font-weight: normal !important;
                                            }

                                            .fromtopopup input:focus {
                                                outline: 0;
                                                border: 0;
                                            }
                                        </style>
                                    </form>

                                    <a id="searchengine_btn" href="flight_search.html">Search</a>

                                    <!-- <button id="searchengine_btn" onclick="next()">Search</button> -->
                                    <script src="<?php echo e(env('ASSETS_URL')); ?>bundles/autocomplate41de?v=12342424d23424567fffsss"></script>

                                </div>

                            </div>

                            <div class="tab-pane fade show" id="hotel" role="tabpanel" aria-labelledby="hotel-tab">
                                <div class="booking_form">
                                    <script src="<?php echo e(env('ASSETS_URL')); ?>bundles/seachengine02b9?v=4242424242424"></script>

                                    <form action="" method="post">
                                        <input id="from_wait" value="" type="hidden" />
                                        <input id="to_wait" value="" type="hidden" />
                                        <input type="hidden" name="device_app" id="device_app" value="2" />
                                        <input type="hidden" name="hfFromDate" id="hfFromDate" value="04/12/2020" />
                                        <input type="hidden" name="hfToDate" id="hfToDate" value="" />
                                        <input type="hidden" name="hfTripType" id="hfTripType" value="false" />
                                        <input type="hidden" name="hfAdult" id="hfAdult" value="" />
                                        <input type="hidden" name="hfChild" id="hfChild" value='' />
                                        <input type="hidden" name="hfInfant" id="hfInfant" value='' />
                                        <input type="hidden" name="hfdirect" id="hfdirect" />
                                        <input type="hidden" name="hdn_flying_from" id="hdn_flying_from" value="" />
                                        <input type="hidden" name="hdn_flying_to" id="hdn_flying_to" value="" />
                                        <input type="hidden" name="modify" id="modify" value="1" />

                                        <section class="serchBox">


                                            <div class="searchEng">

                                                <div class="srcformbx">

                                                    <div class="col-6 col-lg-6 lbl swap">
                                                        <strong class="swap">DESTINATION</strong>

                                                        <i class="fas fa-map-marker-alt desti-icon_lft"></i>
                                                        <input type="text" name="flying_from_N" value="" class="fly-from-input desti-from-input" placeholder="Enter City, Area or Hotel name" id="flying_from_N" onclick="autodiv_from();" autocomplete="off" />

                                                        <div class="fromtopopup frompopup">
                                                            <label>
                                                                <i class="fa fa-search"></i>
                                                                <input type="text" name="flying_from" class="fly-from-input ac_input" autocomplete="off" placeholder="From" id="flying_from" />
                                                            </label>
                                                            <div class="staticway">
                                                                <h5>Popular Cities</h5>
                                                                <ul>
                                                                    <li onclick="setsearhengine('Delhi', 'DEL', 'Indira Gandhi International Airport', 'India', 'IN')">
                                                                        Delhi</li>
                                                                    <li onclick="setsearhengine('Bangalore', 'BLR', 'Bengaluru International Airport', 'India', 'IN')">
                                                                        Bangalore</li>
                                                                    <li onclick="setsearhengine('Mumbai', 'BOM', 'Chhatrapati Shivaji International Airport', 'India', 'IN')">
                                                                        Mumbai</li>
                                                                    <li onclick="setsearhengine('Hyderabad', 'HYD', 'Shamshabad Rajiv Gandhi International Airport', 'India', 'IN')">
                                                                        Hyderabad</li>
                                                                    <li onclick="setsearhengine('Kolkata', 'CCU', 'Netaji Subhas Chandra Bose International Airport', 'India', 'IN')">
                                                                        Kolkata</li>
                                                                    <li onclick="setsearhengine('Chennai', 'MAA', 'Chennai Airport', 'India', 'IN')">
                                                                        Chennai/Madras</li>
                                                                    <li onclick="setsearhengine('Ahmedabad', 'AMD', 'Ahmedabad International Airport', 'India', 'IN')">
                                                                        Ahmedabad</li>
                                                                    <li onclick="setsearhengine('Pune', 'PNQ', 'Lohegaon Airport', 'India', 'IN')">
                                                                        Pune</li>
                                                                    <li onclick="setsearhengine('Guwahati', 'GAU', 'Bordoloi International Airport', 'India', 'IN')">
                                                                        Guwahati</li>
                                                                    <li onclick="setsearhengine('Goa', 'GOI', 'Dabolim Airport', 'India', 'IN')">
                                                                        Goa</li>
                                                                    <li onclick="setsearhengine('Lucknow', 'LKO', 'Amausi Airport', 'India', 'IN')">
                                                                        Lucknow</li>
                                                                    <li onclick="setsearhengine('Bhubaneswar', 'BBI', 'Biju Patnaik Airport', 'India', 'IN')">
                                                                        Bhubaneswar</li>
                                                                    <li onclick="setsearhengine('Cochin', 'COK', 'Chochin International Airport', 'India', 'IN')">
                                                                        Cochin</li>
                                                                    <li onclick="setsearhengine('Jaipur', 'JAI', 'Sanganeer Airport', 'India', 'IN')">
                                                                        Jaipur</li>
                                                                    <li onclick="setsearhengine('Patna', 'PAT', 'Jai Prakash Narayan Airport', 'India', 'IN')">
                                                                        Patna</li>
                                                                    <li onclick="setsearhengine('Srinagar', 'SXR', 'Srinagar International Airport', 'India', 'IN')">
                                                                        Srinagar</li>
                                                                    <li onclick="setsearhengine('Nagpur', 'NAG', 'Dr Ambedkar International Airport', 'India', 'IN')">
                                                                        Nagpur</li>
                                                                    <li onclick="setsearhengine('Agartala', 'IXA', 'Singerbhil Airport', 'India', 'IN')">
                                                                        Agartala</li>
                                                                </ul>
                                                            </div>

                                                        </div>
                                                    </div>


                                                    <div class="col-6 col-lg-2 lbl" id="Fly_dep_datepickerid" style="border-bottom: 1px solid #cbcbcb;">
                                                        <strong>Check In <i class="fa fa-angle-down"></i></strong>
                                                        <input id="datepicker_3" placeholder="00/00/0000" style="font-size: 20px;margin-top: 19px;">
                                                    </div>

                                                    <div class="col-6 col-lg-2 lbl" id="Fly_dep_datepickerid" style="border-bottom: 1px solid #cbcbcb;">
                                                        <strong>Check Out <i class="fa fa-angle-down"></i></strong>
                                                        <input id="datepicker_4" placeholder="00/00/0000" style="font-size: 20px;margin-top: 19px;">
                                                    </div>

                                                    <div class="col-12 col-lg-2 lbl lst" id="adult_div" style="border-bottom: 1px solid #cbcbcb;">
                                                        <input type="hidden" id="adult" name="adult" value="1" />
                                                        <strong>Rooms & Guests <i class="fa fa-angle-down"></i></strong>
                                                        <span style="font-size: 18px; margin-top: 20px;"><big id="travel_id" style="font-size: 18px;">1</big> Rooms, 2 Guests</span>
                                                    </div>




                                                    <div class="col-6 col-lg-3 lbl" id="Fly_dep_datepickerid" style="min-height: 52px; border-top: 1px solid #cbcbcb;">
                                                        <strong>Nationality</strong>
                                                        <select name="" id="" class="national_dropdn">
                                                            <option value="">India</option>
                                                            <option value="">China</option>
                                                            <option value="">America</option>
                                                            <option value="">Japan</option>
                                                        </select>
                                                    </div>

                                                    <div class="col-6 col-lg-3 lbl" id="Fly_dep_datepickerid" style="min-height: 52px; border-top: 1px solid #cbcbcb;">
                                                        <strong>Residence</strong>
                                                        <select name="" id="" class="national_dropdn">
                                                            <option value="">India</option>
                                                            <option value="">China</option>
                                                            <option value="">America</option>
                                                            <option value="">Japan</option>
                                                        </select>
                                                    </div>






                                                    <div class="popup adultdrop">
                                                        <span class="adult1">
                                                            <span class="ad_left">
                                                                <img src="<?php echo e(env('ASSETS_URL')); ?>img/adult.png" alt="Adult Flights">
                                                                Adults (12+)
                                                            </span> <span class="ad_right">
                                                                <input type="button" class="minus maincalulation" value="-" id="sub1minus">
                                                                <input type="text" class="count" value="1" id="sub1">
                                                                <input type="button" class="plus maincalulation" value="+" id="sub1plus">
                                                            </span>
                                                        </span>
                                                        <span class="adult1">
                                                            <span class="ad_left">
                                                                <img src="<?php echo e(env('ASSETS_URL')); ?>img/child.png" alt="Child Flights">
                                                                Children (2-11)
                                                            </span>
                                                            <span class="ad_right">
                                                                <input type="button" class="minus maincalulation" value="-" id="sub2minus">
                                                                <input type="text" class="count" value="0" id="sub2">
                                                                <input type="button" class="plus maincalulation" value="+" id="sub2plus">
                                                            </span>
                                                        </span>
                                                        <span class="adult1">
                                                            <span class="ad_left">
                                                                <img src="<?php echo e(env('ASSETS_URL')); ?>img/infant.png" alt="Infant Flights">
                                                                Infant
                                                            </span>
                                                            <span class="ad_right">
                                                                <input type="button" class="minus maincalulation" value="-" id="sub3minus">
                                                                <input type="text" class="count" value="0" id="sub3">
                                                                <input type="button" class="plus maincalulation" value="+" id="sub3plus">
                                                            </span>
                                                        </span>
                                                        <div>
                                                            <span>&nbsp;</span>
                                                            <span>Choose Travel Class</span>
                                                        </div>
                                                        <div class="search-sixbox">
                                                            <select name="ddlCabinClass" id="ddlCabinClass" onchange="getval_Cabin();" class=" fly-cabin-input ac_input">
                                                                <option value="2" selected="selected">Economy</option>
                                                                <option value="3">Premium Economy</option>
                                                                <option value="4">Business</option>
                                                                <option value="6">First</option>
                                                            </select>

                                                            <div class="search-eightbox" style="display:none;">
                                                                <div class="custom-control custom-checkbox pt-2 text-left">
                                                                    <input type="checkbox" id="chkIsDirect" class="custom-control-input">
                                                                    <label class="custom-control-label" for="chkIsDirect">Direct
                                                                        Flight</label>
                                                                </div>
                                                            </div>

                                                        </div>
                                                        <span class="done"><a>Done</a></span>

                                                    </div>

                                                </div>
                                            </div>

                                        </section>
                                        <style>
                                            .fromtopopup {
                                                display: none;
                                                width: 340px;
                                                position: absolute;
                                                left: 0;
                                                top: 30px;
                                                float: left;
                                                -webkit-border-radius: 4px;
                                                -moz-border-radius: 4px;
                                                border-radius: 4px;
                                                background-color: #ffffff;
                                                -webkit-box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.2);
                                                -moz-box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.2);
                                                box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.2);
                                                z-index: 9999;
                                            }

                                            .fromtopopup label {
                                                width: 100%;
                                                position: relative;
                                                min-height: auto;
                                            }

                                            .fromtopopup label i {
                                                position: absolute;
                                                left: 10px;
                                                top: 15px;
                                                font-size: 12px;
                                            }

                                            .fromtopopup p {
                                                color: #666;
                                                font-size: 13px;
                                                padding: 0px 10px;
                                            }

                                            .fromtopopup input {
                                                width: 100% !important;
                                                background: #ffffff !important;
                                                -webkit-box-shadow: 0 2px 3px 0 rgba(204, 204, 204, 0.1);
                                                -moz-box-shadow: 0 2px 3px 0 rgba(204, 204, 204, 0.1);
                                                box-shadow: 0 2px 3px 0 rgba(204, 204, 204, 0.1);
                                                padding: 11px 10px 11px 30px;
                                                outline: 0;
                                                border: 0;
                                                width: 100%;
                                                font-size: 15px !important;
                                                color: #666;
                                                font-weight: normal !important;
                                            }

                                            .fromtopopup input:focus {
                                                outline: 0;
                                                border: 0;
                                            }
                                        </style>
                                    </form>

                                    <a id="searchengine_btn" href="hotel_search.html">Search</a>

                                    <!-- <button id="searchengine_btn" onclick="next()">Search</button> -->
                                    <script src="<?php echo e(env('ASSETS_URL')); ?>bundles/autocomplate41de?v=12342424d23424567fffsss"></script>

                                </div>

                            </div>

                            <div class="tab-pane fade show" id="hotel_flight" role="tabpanel" aria-labelledby="hotel-tab">
                                <div class="booking_form">
                                    <script src="<?php echo e(env('ASSETS_URL')); ?>bundles/seachengine02b9?v=4242424242424"></script>

                                    <form action="" method="post">
                                        <input id="from_wait" value="" type="hidden" />
                                        <input id="to_wait" value="" type="hidden" />
                                        <input type="hidden" name="device_app" id="device_app" value="2" />
                                        <input type="hidden" name="hfFromDate" id="hfFromDate" value="04/12/2020" />
                                        <input type="hidden" name="hfToDate" id="hfToDate" value="" />
                                        <input type="hidden" name="hfTripType" id="hfTripType" value="false" />
                                        <input type="hidden" name="hfAdult" id="hfAdult" value="" />
                                        <input type="hidden" name="hfChild" id="hfChild" value='' />
                                        <input type="hidden" name="hfInfant" id="hfInfant" value='' />
                                        <input type="hidden" name="hfdirect" id="hfdirect" />
                                        <input type="hidden" name="hdn_flying_from" id="hdn_flying_from" value="" />
                                        <input type="hidden" name="hdn_flying_to" id="hdn_flying_to" value="" />
                                        <input type="hidden" name="modify" id="modify" value="1" />

                                        <section class="serchBox">


                                            <div class="searchEng">
                                                <div class="waybtn">
                                                    <button onclick="return SelectTripType('O')" class="slt oneway">One way</button>
                                                    <button class="roundway" onclick="return SelectTripType('R')">Round trip</button>
                                                </div>



                                                <div class="srcformbx">

                                                    <div class="col-6 col-lg-3 lbl swap">
                                                        <strong class="swap">From </strong>
                                                        <input type="text" name="flying_from_N" value="" class="fly-from-input" placeholder="From" id="flying_from_N" onclick="autodiv_from();" autocomplete="off" />
                                                        <b id="Fly_Depart_airport">Airport Name or City Name</b>
                                                        <img src="<?php echo e(env('ASSETS_URL')); ?>img/swap.png" style="cursor:pointer;" onclick="swapfun()" width="31" height="30" alt="Swap" title="Swap">
                                                        <div class="fromtopopup frompopup">
                                                            <label>
                                                                <i class="fa fa-search"></i>
                                                                <input type="text" name="flying_from" class="fly-from-input ac_input" autocomplete="off" placeholder="From" id="flying_from" />
                                                            </label>
                                                            <div class="staticway">
                                                                <h5>Popular Cities</h5>
                                                                <ul>
                                                                    <li onclick="setsearhengine('Delhi', 'DEL', 'Indira Gandhi International Airport', 'India', 'IN')">
                                                                        Delhi</li>
                                                                    <li onclick="setsearhengine('Bangalore', 'BLR', 'Bengaluru International Airport', 'India', 'IN')">
                                                                        Bangalore</li>
                                                                    <li onclick="setsearhengine('Mumbai', 'BOM', 'Chhatrapati Shivaji International Airport', 'India', 'IN')">
                                                                        Mumbai</li>
                                                                    <li onclick="setsearhengine('Hyderabad', 'HYD', 'Shamshabad Rajiv Gandhi International Airport', 'India', 'IN')">
                                                                        Hyderabad</li>
                                                                    <li onclick="setsearhengine('Kolkata', 'CCU', 'Netaji Subhas Chandra Bose International Airport', 'India', 'IN')">
                                                                        Kolkata</li>
                                                                    <li onclick="setsearhengine('Chennai', 'MAA', 'Chennai Airport', 'India', 'IN')">
                                                                        Chennai/Madras</li>
                                                                    <li onclick="setsearhengine('Ahmedabad', 'AMD', 'Ahmedabad International Airport', 'India', 'IN')">
                                                                        Ahmedabad</li>
                                                                    <li onclick="setsearhengine('Pune', 'PNQ', 'Lohegaon Airport', 'India', 'IN')">
                                                                        Pune</li>
                                                                    <li onclick="setsearhengine('Guwahati', 'GAU', 'Bordoloi International Airport', 'India', 'IN')">
                                                                        Guwahati</li>
                                                                    <li onclick="setsearhengine('Goa', 'GOI', 'Dabolim Airport', 'India', 'IN')">
                                                                        Goa</li>
                                                                    <li onclick="setsearhengine('Lucknow', 'LKO', 'Amausi Airport', 'India', 'IN')">
                                                                        Lucknow</li>
                                                                    <li onclick="setsearhengine('Bhubaneswar', 'BBI', 'Biju Patnaik Airport', 'India', 'IN')">
                                                                        Bhubaneswar</li>
                                                                    <li onclick="setsearhengine('Cochin', 'COK', 'Chochin International Airport', 'India', 'IN')">
                                                                        Cochin</li>
                                                                    <li onclick="setsearhengine('Jaipur', 'JAI', 'Sanganeer Airport', 'India', 'IN')">
                                                                        Jaipur</li>
                                                                    <li onclick="setsearhengine('Patna', 'PAT', 'Jai Prakash Narayan Airport', 'India', 'IN')">
                                                                        Patna</li>
                                                                    <li onclick="setsearhengine('Srinagar', 'SXR', 'Srinagar International Airport', 'India', 'IN')">
                                                                        Srinagar</li>
                                                                    <li onclick="setsearhengine('Nagpur', 'NAG', 'Dr Ambedkar International Airport', 'India', 'IN')">
                                                                        Nagpur</li>
                                                                    <li onclick="setsearhengine('Agartala', 'IXA', 'Singerbhil Airport', 'India', 'IN')">
                                                                        Agartala</li>
                                                                </ul>
                                                            </div>

                                                        </div>
                                                    </div>

                                                    <div class="col-6 col-lg-3 lbl">

                                                        <strong>To</strong>
                                                        <input name="flying_to_N" type="text" class="fly-to-input" value="" placeholder="To" id="flying_to_N" onclick="autodiv_to();" autocomplete="off" />
                                                        <b id="Fly_Dest_airport">Airport Name or City Name</b>

                                                        <div class="fromtopopup topopup">
                                                            <label>
                                                                <i class="fa fa-search"></i>

                                                                <input type="text" name="flying_to" class="fly-from-input ac_input" autocomplete="off" placeholder="To" id="flying_to" />
                                                            </label>
                                                            <div class="staticway">
                                                                <h5>Popular Cities</h5>
                                                                <ul>
                                                                    <li onclick="setsearhengine_Return('Delhi', 'DEL', 'Indira Gandhi International Airport', 'India', 'IN')">
                                                                        Delhi</li>
                                                                    <li onclick="setsearhengine_Return('Bangalore', 'BLR', 'Bengaluru International Airport', 'India', 'IN')">
                                                                        Bangalore</li>
                                                                    <li onclick="setsearhengine_Return('Mumbai', 'BOM', 'Chhatrapati Shivaji International Airport', 'India', 'IN')">
                                                                        Mumbai</li>
                                                                    <li onclick="setsearhengine_Return('Hyderabad', 'HYD', 'Shamshabad Rajiv Gandhi International Airport', 'India', 'IN')">
                                                                        Hyderabad</li>
                                                                    <li onclick="setsearhengine_Return('Kolkata', 'CCU', 'Netaji Subhas Chandra Bose International Airport', 'India', 'IN')">
                                                                        Kolkata</li>
                                                                    <li onclick="setsearhengine_Return('Chennai', 'MAA', 'Chennai Airport', 'India', 'IN')">
                                                                        Chennai/Madras</li>
                                                                    <li onclick="setsearhengine_Return('Ahmedabad', 'AMD', 'Ahmedabad International Airport', 'India', 'IN')">
                                                                        Ahmedabad</li>
                                                                    <li onclick="setsearhengine_Return('Pune', 'PNQ', 'Lohegaon Airport', 'India', 'IN')">
                                                                        Pune</li>
                                                                    <li onclick="setsearhengine_Return('Guwahati', 'GAU', 'Bordoloi International Airport', 'India', 'IN')">
                                                                        Guwahati</li>
                                                                    <li onclick="setsearhengine_Return('Goa', 'GOI', 'Dabolim Airport', 'India', 'IN')">
                                                                        Goa</li>
                                                                    <li onclick="setsearhengine_Return('Lucknow', 'LKO', 'Amausi Airport', 'India', 'IN')">
                                                                        Lucknow</li>
                                                                    <li onclick="setsearhengine_Return('Bhubaneswar', 'BBI', 'Biju Patnaik Airport', 'India', 'IN')">
                                                                        Bhubaneswar</li>
                                                                    <li onclick="setsearhengine_Return('Cochin', 'COK', 'Chochin International Airport', 'India', 'IN')">
                                                                        Cochin</li>
                                                                    <li onclick="setsearhengine_Return('Jaipur', 'JAI', 'Sanganeer Airport', 'India', 'IN')">
                                                                        Jaipur</li>
                                                                    <li onclick="setsearhengine_Return('Patna', 'PAT', 'Jai Prakash Narayan Airport', 'India', 'IN')">
                                                                        Patna</li>
                                                                    <li onclick="setsearhengine_Return('Srinagar', 'SXR', 'Srinagar International Airport', 'India', 'IN')">
                                                                        Srinagar</li>
                                                                    <li onclick="setsearhengine_Return('Nagpur', 'NAG', 'Dr Ambedkar International Airport', 'India', 'IN')">
                                                                        Nagpur</li>
                                                                    <li onclick="setsearhengine_Return('Agartala', 'IXA', 'Singerbhil Airport', 'India', 'IN')">
                                                                        Agartala</li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-6 col-lg-2 lbl" id="Fly_dep_datepickerid">
                                                        <strong>Departure <i class="fa fa-angle-down"></i></strong>
                                                        <input id="datepicker_1" placeholder="00/00/0000" style="font-size: 20px;margin-top: 19px;">
                                                    </div>
                                                    <div class="col-6 col-lg-2 lbl" onclick="return SelectTripType('R')" id="Fly_ret_datepickerid" disabled="disabled" style="cursor: no-drop; background: #f5f2f2; ">
                                                        <strong>Return <i class="fa fa-angle-down"></i></strong>
                                                        <input id="datepicker_2" placeholder="00/00/0000" style="font-size: 20px;margin-top: 19px;">
                                                    </div>
                                                    <div class="col-12 col-lg-2 lbl lst" id="adult_div">
                                                        <input type="hidden" id="adult" name="adult" value="1" />
                                                        <strong>Travellers & Class <i class="fa fa-angle-down"></i></strong>
                                                        <span><big id="travel_id">1</big> Traveller</span>
                                                        <b id="cabin_id">Economy</b>

                                                    </div>

                                                    <div class="popup adultdrop">
                                                        <span class="adult1">
                                                            <span class="ad_left">
                                                                <img src="<?php echo e(env('ASSETS_URL')); ?>img/adult.png" alt="Adult Flights">
                                                                Adults (12+)
                                                            </span> <span class="ad_right">
                                                                <input type="button" class="minus maincalulation" value="-" id="sub1minus">
                                                                <input type="text" class="count" value="1" id="sub1">
                                                                <input type="button" class="plus maincalulation" value="+" id="sub1plus">
                                                            </span>
                                                        </span>
                                                        <span class="adult1">
                                                            <span class="ad_left">
                                                                <img src="<?php echo e(env('ASSETS_URL')); ?>img/child.png" alt="Child Flights">
                                                                Children (2-11)
                                                            </span>
                                                            <span class="ad_right">
                                                                <input type="button" class="minus maincalulation" value="-" id="sub2minus">
                                                                <input type="text" class="count" value="0" id="sub2">
                                                                <input type="button" class="plus maincalulation" value="+" id="sub2plus">
                                                            </span>
                                                        </span>
                                                        <span class="adult1">
                                                            <span class="ad_left">
                                                                <img src="<?php echo e(env('ASSETS_URL')); ?>img/infant.png" alt="Infant Flights">
                                                                Infant
                                                            </span>
                                                            <span class="ad_right">
                                                                <input type="button" class="minus maincalulation" value="-" id="sub3minus">
                                                                <input type="text" class="count" value="0" id="sub3">
                                                                <input type="button" class="plus maincalulation" value="+" id="sub3plus">
                                                            </span>
                                                        </span>
                                                        <div>
                                                            <span>&nbsp;</span>
                                                            <span>Choose Travel Class</span>
                                                        </div>
                                                        <div class="search-sixbox">
                                                            <select name="ddlCabinClass" id="ddlCabinClass" onchange="getval_Cabin();" class=" fly-cabin-input ac_input">
                                                                <option value="2" selected="selected">Economy</option>
                                                                <option value="3">Premium Economy</option>
                                                                <option value="4">Business</option>
                                                                <option value="6">First</option>
                                                            </select>

                                                            <div class="search-eightbox" style="display:none;">
                                                                <div class="custom-control custom-checkbox pt-2 text-left">
                                                                    <input type="checkbox" id="chkIsDirect" class="custom-control-input">
                                                                    <label class="custom-control-label" for="chkIsDirect">Direct
                                                                        Flight</label>
                                                                </div>
                                                            </div>

                                                        </div>
                                                        <span class="done"><a>Done</a></span>

                                                    </div>

                                                </div>
                                            </div>

                                        </section>
                                        <style>
                                            .fromtopopup {
                                                display: none;
                                                width: 340px;
                                                position: absolute;
                                                left: 0;
                                                top: 30px;
                                                float: left;
                                                -webkit-border-radius: 4px;
                                                -moz-border-radius: 4px;
                                                border-radius: 4px;
                                                background-color: #ffffff;
                                                -webkit-box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.2);
                                                -moz-box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.2);
                                                box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.2);
                                                z-index: 9999;
                                            }

                                            .fromtopopup label {
                                                width: 100%;
                                                position: relative;
                                                min-height: auto;
                                            }

                                            .fromtopopup label i {
                                                position: absolute;
                                                left: 10px;
                                                top: 15px;
                                                font-size: 12px;
                                            }

                                            .fromtopopup p {
                                                color: #666;
                                                font-size: 13px;
                                                padding: 0px 10px;
                                            }

                                            .fromtopopup input {
                                                width: 100% !important;
                                                background: #ffffff !important;
                                                -webkit-box-shadow: 0 2px 3px 0 rgba(204, 204, 204, 0.1);
                                                -moz-box-shadow: 0 2px 3px 0 rgba(204, 204, 204, 0.1);
                                                box-shadow: 0 2px 3px 0 rgba(204, 204, 204, 0.1);
                                                padding: 11px 10px 11px 30px;
                                                outline: 0;
                                                border: 0;
                                                width: 100%;
                                                font-size: 15px !important;
                                                color: #666;
                                                font-weight: normal !important;
                                            }

                                            .fromtopopup input:focus {
                                                outline: 0;
                                                border: 0;
                                            }
                                        </style>
                                    </form>

                                    <a id="searchengine_btn" href="hotel_flight_search.html">Search</a>

                                    <!-- <button id="searchengine_btn" onclick="next()">Search</button> -->
                                    <script src="<?php echo e(env('ASSETS_URL')); ?>bundles/autocomplate41de?v=12342424d23424567fffsss"></script>

                                </div>

                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Header part end-->

    <!--top place start-->
    <section class="top_place section_padding">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6">
                    <div class="section_tittle text-center">
                        <h2>FEATURED TRIP</h2>
                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-lg-12 col-md-12">
                    <div class="top_package_adst">


                        <div class="row single_place top_package_row">

                            <div class="col-md-6"></div>

                            <div class="col-md-6 package_btm_detail package_top_detail">
                                <h2>Luxury Greece</h2>
                                <h5>6 Days 5 Night</h5>
                                <p>Lorem ipsum dolor sit amet, id altera persequeris vim, mea an appareat prodesset. Cu mea error eripuit delicata. Nec soluta aliquid similique eu, eu melius constituam sit. Et nam soleat accusamus. Vim hinc aeque viderer no.</p>
                                <a href="#" class="place_btn">View Detail</a>
                            </div>
                        </div>

                    </div>
                </div>



                <div class="col-lg-6 col-md-6">
                    <div class="single_place">
                        <img src="<?php echo e(env('ASSETS_URL')); ?>img/package_img2.png" alt="">
                        <div class="hover_Text d-flex align-items-end justify-content-between">
                            <div class="hover_text_iner">
                                <a href="#" class="place_btn">View Detail</a>
                            </div>

                        </div>

                        <div class="package_btm_detail">
                            <h2>Belgia Village</h2>
                            <h5>3 Days 2 Night</h5>
                            <p>Lorem ipsum dolor sit amet, id altera persequeris vim, mea an appareat prodesset. Cu mea error eripuit delicata. Nec soluta aliquid similique eu, eu melius constituam sit. Et nam soleat accusamus. Vim hinc aeque viderer no.</p>
                        </div>
                    </div>
                </div>


                <div class="col-lg-6 col-md-6">
                    <div class="single_place">
                        <img src="<?php echo e(env('ASSETS_URL')); ?>img/package_img3.png" alt="">
                        <div class="hover_Text d-flex align-items-end justify-content-between">
                            <div class="hover_text_iner">
                                <a href="#" class="place_btn">View Detail</a>
                            </div>

                        </div>

                        <div class="package_btm_detail">
                            <h2>Middle East Paradise</h2>
                            <h5>6 Days 5 Night</h5>
                            <p>Lorem ipsum dolor sit amet, id altera persequeris vim, mea an appareat prodesset. Cu mea error eripuit delicata. Nec soluta aliquid similique eu, eu melius constituam sit. Et nam soleat accusamus. Vim hinc aeque viderer no.</p>
                        </div>
                    </div>
                </div>


                <div class="col-md-12 text-center">
                    <a href="#" class="veiw_more_btn">VIEW MORE DESTINATION</a>
                </div>


            </div>
        </div>
    </section>
    <!--top place end-->

    <!--top place start-->
    <section class="event_part section_padding">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6">
                    <div class="section_tittle text-center">
                        <h2 style="color: #fff;">OUR PACKAGE</h2>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-3 our_package_hm">
                    <h2>Luxury Paradise</h2>
                    <span></span>
                    <p>Lorem ipsum dolor sit amet, id altera
                        persequeris vim, mea an appareat prodesset.
                        Cu mea error eripuit delicata. Nec soluta aliquid
                        similique eu.</p>
                </div>

                <div class="col-md-3 our_package_hm">
                    <h2>Deluxe Gold</h2>
                    <span></span>
                    <p>Lorem ipsum dolor sit amet, id altera
                        persequeris vim, mea an appareat prodesset.
                        Cu mea error eripuit delicata. Nec soluta aliquid
                        similique eu.</p>
                </div>

                <div class="col-md-3 our_package_hm">
                    <h2>Premium Silver</h2>
                    <span></span>
                    <p>Lorem ipsum dolor sit amet, id altera
                        persequeris vim, mea an appareat prodesset.
                        Cu mea error eripuit delicata. Nec soluta aliquid
                        similique eu.</p>
                </div>


                <div class="col-md-3 our_package_hm">
                    <h2>Premium Silver</h2>
                    <span></span>
                    <p>Lorem ipsum dolor sit amet, id altera
                        persequeris vim, mea an appareat prodesset.
                        Cu mea error eripuit delicata. Nec soluta aliquid
                        similique eu.</p>
                </div>


            </div>
        </div>
    </section>
    <!--top place end-->

    <!--::industries start::-->
    <section class="best_services section_padding">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6">
                    <div class="section_tittle text-center">
                        <h2>WE OFFERED BEST SERVICES</h2>
                        <p>Lorem ipsum dolor sit amet, id altera persequeris vim, mea an appareat prodesset. Cu mea error eripuit delicata. Nec soluta aliquid similique eu, eu melius constituam sit.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-sm-6">
                    <div class="single_ihotel_list">
                        <img src="<?php echo e(env('ASSETS_URL')); ?>img/services_1.png" alt="">

                        <div class="we_offer_details">
                            <h3> <a href="#"> Transportation</a></h3>
                            <p>All transportation cost we bear</p>
                        </div>

                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="single_ihotel_list">
                        <img src="<?php echo e(env('ASSETS_URL')); ?>img/services_2.png" alt="">
                        <div class="we_offer_details">
                            <h3> <a href="#"> Guidence</a></h3>
                            <p>We offer the best guidence for you</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="single_ihotel_list">
                        <img src="<?php echo e(env('ASSETS_URL')); ?>img/services_3.png" alt="">
                        <div class="we_offer_details">
                            <h3> <a href="#"> Accomodation</a></h3>
                            <p>Luxarious and comfortable</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="single_ihotel_list">
                        <img src="<?php echo e(env('ASSETS_URL')); ?>img/services_4.png" alt="">
                        <div class="we_offer_details">
                            <h3> <a href="#"> Discover world</a></h3>
                            <p>Best tour plan for your next tour</p>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--::industries end::-->

    <!--::industries start::-->
    <section class="best_services section_padding pt-0">
        <div class="container">

            <div class="row">
                <div class="col-lg-3 col-sm-6">
                    <div class="single_ihotel_list single_ihotel_list_li text-center">
                        <img src="<?php echo e(env('ASSETS_URL')); ?>img/traveller.svg" alt="">
                        <h3 style="margin-bottom: 0;"><strong>120,859</strong></h3>
                        <p style="font-size: 15px;">HAPPY TRAVELLERS</p>
                    </div>
                </div>

                <div class="col-lg-3 col-sm-6">
                    <div class="single_ihotel_list single_ihotel_list_li text-center">
                        <img src="<?php echo e(env('ASSETS_URL')); ?>img/satis_tour.svg" alt="">
                        <h3 style="margin-bottom: 0;"><strong>2594</strong></h3>
                        <p style="font-size: 15px;">SATISFIED TOURS</p>
                    </div>
                </div>

                <div class="col-lg-3 col-sm-6">
                    <div class="single_ihotel_list single_ihotel_list_li text-center">
                        <img src="<?php echo e(env('ASSETS_URL')); ?>img/world.svg" alt="">
                        <h3 style="margin-bottom: 0;"><strong>854</strong></h3>
                        <p style="font-size: 15px;">DESTINATION</p>
                    </div>
                </div>

                <div class="col-lg-3 col-sm-6">
                    <div class="single_ihotel_list single_ihotel_list_li text-center">
                        <img src="<?php echo e(env('ASSETS_URL')); ?>img/destination.svg" alt="">
                        <h3 style="margin-bottom: 0;"><strong>978</strong></h3>
                        <p style="font-size: 15px;">DESTINATIONS</p>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!--::industries end::-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skiez\resources\views/welcome.blade.php ENDPATH**/ ?>